#-*-coding:utf-8-*-
#!/usr/bin/env python3
N = 1


def plus_plus(n=0):
    global N
    if n == 0:
        N = 1
    else:
        N = N + 1
    return N


property_addresss = {
    #     #
    'vbus_voltage': 00000 + plus_plus(0), # 只读
    'ibus': 00000 + plus_plus(1), # 只读
    # config. #
    # can. #
    'can.error': 20000 + plus_plus(0), # 只读
    # can.config. #
    'can.config.baud_rate': 21000 + plus_plus(0), # CAN波特率
    'can.config.enable_state_feedback': 22000 + plus_plus(0), # 是否开启CAN实时状态反馈
    # dr. #
    'dr.error': 30000 + plus_plus(0), # 只读
    'dr.current_state': 30000 + plus_plus(1), # 只读
    'dr.requested_state': 30000 + plus_plus(1), # 设置运行状态
    # dr.config. #
    'dr.config.can_node_id': 31000 + plus_plus(0), # CAN总线节点 ID 号
    'dr.config.state_feedback_rate_ms': 31000 + plus_plus(1), # CAN心跳信号发送的时间间隔，默认为 2，单位 ms，当总线中不同 ID 号关节数量为 n 时，需将该值设置为 2n
    'dr.config.product_model': 31000 + plus_plus(1), # 产品型号（只读）
    # dr.config. #
    'dr.config.enable_angle_limit': 31200 + plus_plus(0), # 是否开启角度限制属性，默认不开启
    'dr.config.angle_min': 31200 + plus_plus(1), # 最小角度限位 默认为-180°
    'dr.config.angle_max': 31200 + plus_plus(1),# 最大角度限位 默认为180°
    'dr.config.gear_ratio': 31200 + plus_plus(1), # 只读 减速比
    'dr.config.stall_current_limit': 31200 + plus_plus(1), # 堵转电流
    'dr.config.enable_crash_detect': 31200 + plus_plus(1), # 是否开启碰撞检测，默认开启
    'dr.config.crash_detect_sensitivity': 31200 + plus_plus(1), # 碰撞检测灵敏度，该值需大于 0，越小越灵敏
    'dr.config.enable_encoder_circular_limit': 31200 + plus_plus(1), # 是否开启多圈计数角度限制，超出该限制关节将无法记住重启前的角度
    # dr.controller. #
    'dr.controller.error': 32000 + plus_plus(0), # 只读
    'dr.controller.trajectory_done': 32000 + plus_plus(1), # 只读
    # dr.controller.config. #
    'dr.controller.config.enable_vel_limit': 32100 + plus_plus(0),# 是否启用转速限制，默认启用
    'dr.controller.config.pos_gain': 32100 + plus_plus(1), # 位置增益
    'dr.controller.config.vel_gain': 32100 + plus_plus(1), # 转速增益
    'dr.controller.config.vel_integrator_gain': 32100 + plus_plus(1), # 转速积分增益
    'dr.controller.config.vel_limit': 32100 + plus_plus(1), # 最大限制转速，此处转速为电机转速，输出端需要考虑减速比
    'dr.controller.config.vel_limit_tolerance': 32100 + plus_plus(1), # 超出最大转速的忍耐度，比如设定为 1.2 时表示当转速超过设定的最大转速值的 1.2 倍才会触发 超速错误：ERROR_OVERSPEED
    'dr.controller.config.inertia': 32100 + plus_plus(1), # 负载转动惯量 默认为0
    'dr.controller.config.input_filter_bandwidth': 32100 + plus_plus(1), # 输入滤波带宽，反应外部控制信号输入的快慢
    # dr.motor. #
    'dr.motor.error': 33000 + plus_plus(0), # 只读
    # dr.motor.config. #
    'dr.motor.config.pole_pairs': 33100 + plus_plus(0), # 只读
    'dr.motor.config.phase_inductance': 33100 + plus_plus(1), # 只读
    'dr.motor.config.phase_resistance': 33100 + plus_plus(1), # 只读
    'dr.motor.config.torque_constant': 33100 + plus_plus(1), # 只读
    'dr.motor.config.current_lim': 33100 + plus_plus(1), # 最大电流限制
    'dr.motor.config.current_lim_margin': 33100 + plus_plus(1), # 最大电流限制忍耐度，如：此值设置为 3 表示当关节电流超过限制电流 3A 时停止关节并报错
    'dr.motor.config.torque_lim': 33100 + plus_plus(1), # 最大力矩限制，此处转速为电机力矩，输出端需要考虑减速比，默认为无穷
    'dr.motor.config.current_control_bandwidth': 33100 + plus_plus(1), # 电流控制带宽
    # dr.motor.current_control. #
    'dr.motor.current_control.Iq_measured': 33200 + plus_plus(0), # 只读
    'dr.motor.current_control.Id_measured': 33200 + plus_plus(1), # 只读
    # dr.encoder. #
    'dr.encoder.error': 34000 + plus_plus(0), # 只读
    'dr.encoder.abs_output': 34000 + plus_plus(1), # 只读

    'dr.encoder.pos_zero_output': 34100 + plus_plus(0), # 只读 设置零点后输出轴编码器零位值（中空关节专属）
    'dr.encoder.abs_pos_power_on': 34100 + plus_plus(1), # 只读 刚启动时读取到的输出轴编码器值（中空关节专属）
    'dr.encoder.first_half_T': 34100 + plus_plus(1), # 中空关节绝对位置误差的前半个周期长度（中空关节专属）
    'dr.encoder.first_half_M': 34100 + plus_plus(1), # 中空关节绝对位置误差的前半个周期幅值（中空关节专属）
    'dr.encoder.second_half_M': 34100 + plus_plus(1), # 中空关节绝对位置误差的后半个周期幅值（中空关节专属）
    'dr.encoder.intercept': 34100 + plus_plus(1), # 中空关节绝对位置误差截距（中空关节专属）
    'dr.encoder.first_half_up': 34100 + plus_plus(1), # 中空关节绝对位置误差的前半个周期幅值是否向上，是则为 1 否则为 0（中空关节专属）
    # dr.fet_thermistor. #
    'dr.fet_thermistor.error': 36000 + plus_plus(0), # 只读
    'dr.fet_thermistor.temperature': 36000 + plus_plus(1), #只读
    # dr.fet_thermistor.config. #
    'dr.fet_thermistor.config.enabled': 36100 + plus_plus(0), # 是否开启驱动板温度保护，默认开启
    'dr.fet_thermistor.config.temp_limit_lower': 36100 + plus_plus(1), # 驱动板温度保护下限，即开始进行保护的温度
    'dr.fet_thermistor.config.temp_limit_upper': 36100 + plus_plus(1), # 驱动板温度保护上限，即完全保护待机的温度
    # dr.motor_thermistor. #
    'dr.motor_thermistor.error': 37000 + plus_plus(0), # 只读
    'dr.motor_thermistor.temperature': 37000 + plus_plus(1), #只读
    # dr.motor_thermistor.config. #
    'dr.motor_thermistor.config.enabled': 37100 + plus_plus(0), # 是否开启电机温度保护，默认开启
    'dr.motor_thermistor.config.temp_limit_lower': 37100 + plus_plus(1), # 电机温度保护下限，即开始进行保护的温度，一般不宜超过80℃
    'dr.motor_thermistor.config.temp_limit_upper': 37100 + plus_plus(1), # 电机温度保护上限，即完全保护待机的温度
    # dr.output_shaft. #
    'dr.output_shaft.pos_estimate': 38000 + plus_plus(0), # 只读
    'dr.output_shaft.vel_estimate': 38000 + plus_plus(1), # 只读
    'dr.output_shaft.torque_estimate': 38000 + plus_plus(1), # 只读
    'dr.output_shaft.angle_min': 38000 + plus_plus(1), # 输出端最小临时角度限位，默认为-180°
    'dr.output_shaft.angle_max': 38000 + plus_plus(1), # 输出端最大临时角度限位，默认为180°
    'dr.output_shaft.enable_angle_limit': 38000 + plus_plus(1), # 是否开启输出端临时角度限位，默认不开启


}

property_type = {
    #     #
    'vbus_voltage': 'f', # 只读
    'ibus': 'f', # 只读
    # can. #
    'can.error': 'u32',
    # can.config. #
    'can.config.baud_rate': 'u32',
    'can.config.enable_state_feedback': 'u32',
    # dr. #
    'dr.error': 'u32',
    'dr.current_state': 'u32',
    'dr.requested_state': 'u32',
    # dr.config. #
    'dr.config.can_node_id': 'u32',
    'dr.config.state_feedback_rate_ms': 'u32',
    'dr.config.product_model': 'u32',
    'dr.config.enable_angle_limit': 'u32',
    'dr.config.angle_min': 'f',
    'dr.config.angle_max': 'f',
    'dr.config.gear_ratio': 'f',
    'dr.config.stall_current_limit': 'f',
    'dr.config.enable_crash_detect': 'u32',
    'dr.config.crash_detect_sensitivity': 'f',
    'dr.config.enable_encoder_circular_limit': 'u32',
    # dr.controller. #
    'dr.controller.error': 'u32',
    'dr.controller.trajectory_done': 'u32',
    # dr.controller.config. #
    'dr.controller.config.enable_gain_scheduling': 'u32',
    'dr.controller.config.enable_vel_limit': 'u32',
    'dr.controller.config.pos_gain': 'f',
    'dr.controller.config.vel_gain': 'f',
    'dr.controller.config.vel_integrator_gain': 'f',
    'dr.controller.config.vel_limit': 'f',
    'dr.controller.config.vel_limit_tolerance': 'f',
    'dr.controller.config.inertia': 'f',
    'dr.controller.config.input_filter_bandwidth': 'f',
    # dr.motor. #
    'dr.motor.error': 'u32',
    # dr.motor.config. #
    'dr.motor.config.pole_pairs': 's32',
    'dr.motor.config.phase_inductance': 'f',
    'dr.motor.config.phase_resistance': 'f',
    'dr.motor.config.torque_constant': 'f',
    'dr.motor.config.current_lim': 'f',
    'dr.motor.config.current_lim_margin': 'f',
    'dr.motor.config.torque_lim': 'f',
    'dr.motor.config.current_control_bandwidth': 'f',
    # dr.motor.current_control. #
    'dr.motor.current_control.Iq_measured': 'f',
    'dr.motor.current_control.Id_measured': 'f',
    # dr.encoder. #
    'dr.encoder.error': 'u32',
    'dr.encoder.abs_output': 's32',

    'dr.encoder.pos_zero_output': 's32',
    'dr.encoder.abs_pos_power_on': 's32',
    'dr.encoder.first_half_T': 'f',
    'dr.encoder.first_half_M': 'f',
    'dr.encoder.second_half_M': 'f',
    'dr.encoder.intercept': 'f',
    'dr.encoder.first_half_up': 'u32',
    # dr.fet_thermistor. #
    'dr.fet_thermistor.error': 'u32',
    'dr.fet_thermistor.temperature': 'f',
    # dr.fet_thermistor.config. #
    'dr.fet_thermistor.config.enabled': 'u32',
    'dr.fet_thermistor.config.temp_limit_lower': 'f',
    'dr.fet_thermistor.config.temp_limit_upper': 'f',
    # dr.motor_thermistor. #
    'dr.motor_thermistor.error': 'u32',
    'dr.motor_thermistor.temperature': 'f',
    # dr.motor_thermistor.config. #
    'dr.motor_thermistor.config.enabled': 'u32',
    'dr.motor_thermistor.config.temp_limit_lower': 'f',
    'dr.motor_thermistor.config.temp_limit_upper': 'f',
    # dr.output_shaft. #
    'dr.output_shaft.pos_estimate': 'f',
    'dr.output_shaft.vel_estimate': 'f',
    'dr.output_shaft.torque_estimate': 'f',
    'dr.output_shaft.angle_min': 'f',
    'dr.output_shaft.angle_max': 'f',
    'dr.output_shaft.enable_angle_limit': 'u32',
}


# 通过属性编码找到名称
def value_find_key(value=1):
    dict_temp = property_addresss
    if value in dict_temp.values():
        return list(dict_temp.keys())[list(dict_temp.values()).index(value)]
    else:
        return 0


# 通过名称找到属性编码
def key_find_value(key=''):
    if 'dr' in key:
        temp = key.split('.', 1)[-1]
        key = 'dr.' + temp
    dict_temp = property_addresss
    if key in dict_temp.keys():
        return dict_temp[key]
    else:
        return 0
