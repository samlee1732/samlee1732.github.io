#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import sys
import math
import moveit_commander
from geometry_msgs.msg import Pose
import tf.transformations as tft


def move_to_pose(x_mm, y_mm, z_mm, roll_deg, pitch_deg, yaw_deg):
    # ================= 单位换算 =================
    # 1. 位置：毫米(mm) -> 米(m)
    x = x_mm / 1000.0
    y = y_mm / 1000.0
    z = z_mm / 1000.0

    # 2. 姿态：度(deg) -> 弧度(rad)
    roll = math.radians(roll_deg)
    pitch = math.radians(pitch_deg)
    yaw = math.radians(yaw_deg)
    # ============================================

    # 3. 初始化 MoveIt
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('cartesian_move_demo', anonymous=True)

    # 4. 替换为你的机械臂规划组名称（通常是 "arm" 或 "manipulator"）
    group_name = "arm"
    group = moveit_commander.MoveGroupCommander(group_name)

    # 设置参考坐标系（通常是 "base_link" 或 "world"）
    group.set_pose_reference_frame("base_link")

    # 5. 将弧度制的 RPY 转换为四元数
    quat = tft.quaternion_from_euler(roll, pitch, yaw)

    # 6. 构建目标位姿
    target_pose = Pose()
    target_pose.position.x = x
    target_pose.position.y = y
    target_pose.position.z = z
    target_pose.orientation.x = quat[0]
    target_pose.orientation.y = quat[1]
    target_pose.orientation.z = quat[2]
    target_pose.orientation.w = quat[3]

    rospy.loginfo("目标位置:x=%f, y=%f, z=%f", target_pose.position.x, target_pose.position.y, target_pose.position.z)
    rospy.loginfo("目标姿态（四元数）：x=%f, y=%f, z=%f, w=%f",target_pose.orientation.x, target_pose.orientation.y, target_pose.orientation.z, target_pose.orientation.w)

    # 7. 设置目标并规划
    group.set_pose_target(target_pose)
    plan_result = group.plan()

    #兼容不同版本的Moveit
    if isinstance(plan_result, tuple):
	success = plan_result[0]
	trajectory = plan_result[1]
    else:
	success = (plan_result is not None and hasattr(plan_result, 'joint_trajectory') and
		len(plan_result.joint_trajectory.points) > 0)
	trajectory = plan_result

    # ROS1 中 plan 返回的是一个元组 (success, trajectory, planning_time, error_code)
    if success and trajectory is not None:
        rospy.loginfo("规划成功，开始执行...")
        group.execute(trajectory, wait=True)
    else:
        rospy.logwarn("规划失败！可能目标超出工作空间、存在碰撞或逆运动学无解。")

    	group.stop()
    	group.clear_pose_targets()
    	moveit_commander.roscpp_shutdown()
	return


if __name__ == '__main__':
    try:
        # ============== 在这里输入你的 6 个变量 ==============
        # 单位说明：
        # x_mm, y_mm, z_mm : 毫米 (mm)
        # roll_deg, pitch_deg, yaw_deg : 度 (°)

        # 示例：X=300mm, Y=100mm, Z=500mm, Roll=0°, Pitch=90°, Yaw=0°
        move_to_pose(x_mm=350.0, y_mm=100.0, z_mm=100.0,
                     roll_deg=90.0, pitch_deg=0.0, yaw_deg=0.0)
        # ====================================================
    except rospy.ROSInterruptException:
        pass
