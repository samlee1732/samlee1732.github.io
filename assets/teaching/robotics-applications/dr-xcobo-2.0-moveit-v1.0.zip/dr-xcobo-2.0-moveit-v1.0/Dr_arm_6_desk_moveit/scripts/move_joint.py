#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import sys
import math
import moveit_commander
from geometry_msgs.msg import Pose
import tf.transformations as tft


def move_by_joint_angles():
    # 1. 初始化 MoveIt
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('joint_move_demo', anonymous=True)

    # 2. 替换为你的机械臂规划组名称（通常是 "arm"）
    group_name = "arm"
    group = moveit_commander.MoveGroupCommander(group_name)

    # 3. 获取当前关节角度
    joint_goal = group.get_current_joint_values()

    # ================= 在这里输入 6 个关节的角度 =================
    # 注意：单位是【弧度】，不是度！(90度 = 1.57)
    # 这里的索引 0~5 对应 URDF 里的 joint_1 到 joint_6

    joint_goal[0] = 0.1  # 关节1
    joint_goal[1] = -0.3  # 关节2
    joint_goal[2] = 0.2  # 关节3
    joint_goal[3] = 0.4  # 关节4
    joint_goal[4] = 0.5  # 关节5
    joint_goal[5] = 0.1  # 关节6
    # ========================================================

    # 4. 设置关节目标并规划
    group.set_joint_value_target(joint_goal)

    # 加大规划尝试次数
    group.set_planning_time(5.0)
    group.set_num_planning_attempts(20)

    rospy.loginfo("开始规划关节运动...")
    plan_result = group.plan()

    # 【兼容不同版本的 MoveIt】
    if isinstance(plan_result, tuple):
        success = plan_result[0]
        trajectory = plan_result[1]
    else:
        success = (plan_result is not None and hasattr(plan_result, 'joint_trajectory')
                   and len(plan_result.joint_trajectory.points) > 0)
        trajectory = plan_result

    if success and trajectory is not None:
        rospy.loginfo("规划成功，开始执行...")
        group.execute(trajectory, wait=True)
    else:
        rospy.logwarn("规划失败！可能是关节角度超出URDF限位，或者发生了自碰撞。")

    group.stop()
    group.clear_pose_targets()
    moveit_commander.roscpp_shutdown()


if __name__ == '__main__':
    try:
        # 调用关节角度控制函数
        move_by_joint_angles()
    except rospy.ROSInterruptException:
        pass
