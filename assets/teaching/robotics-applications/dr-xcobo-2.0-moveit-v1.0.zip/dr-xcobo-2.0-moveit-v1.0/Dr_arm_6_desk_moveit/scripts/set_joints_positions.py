#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import JointState 
import DrEmpower_can as se
import math as cm

angle_list_last = [0, 0, 0, 0, 0, 0]
j = 0 # used to record the time of callback

def callback(data):
    
    global angle_list_last
    global j
    # print(angle_list_last)
    angle_list = []
    for i in range(len(data.position)):
        if i == 1:
            angle_list.append(data.position[i]/cm.pi*180 + 90)
        else:
            angle_list.append(data.position[i]/cm.pi*180)
    if j == 0:
        se.set_angles(id_list=[1, 2, 3, 4, 5, 6], angle_list=angle_list, speed=10, param=10, mode=1)
    print(angle_list)
    if abs(data.position[1] - angle_list_last[1]) > 0.0001:
        print(abs(data.position[1] - angle_list_last[1]))
        se.set_angles(id_list=[1, 2, 3, 4, 5, 6], angle_list=angle_list, speed=10, param=10, mode=1)
    angle_list_last = data.position
    print(angle_list_last)
    j = j + 1
    

def listener():
    rospy.init_node("set_joints_positions_arm_6", anonymous=True)
    rospy.Subscriber("joint_states", JointState, callback)
    rospy.spin()


if __name__ == '__main__':
    listener()
    

