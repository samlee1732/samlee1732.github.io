# Changelog

## 1.0 — 2026-11-14

- Organized the course-provided `robot.zip` as `dr_xcobo` with relative imports;
  renamed `DrEmpower_can.py` to `dr_empower_can.py` and added the `RobotArm` alias.
- Replaced the mixed `test.py` entry point with documented state-reading and
  joint-target examples. Motion is a preview unless `--execute` is specified.
- Added pinned dependencies and Chinese/English connection instructions.
- Removed cached bytecode, local ROS container utilities and personal setup notes.
- Made initialization query-only. It no longer writes joint ranges or sends
  current-position hold commands. An incomplete read raises an error and closes
  the connection. Explicit `range_init()` retains its hardware-write behavior.
- Moved legacy trajectory timing calibration to explicit `calibrate_timing()`;
  timed trajectory entry points reject uncalibrated use.
- Corrected the gripper constructor spelling and isolated mutable state between
  robot connections. A valid zero-degree reading is no longer treated as failure.
- Added bounded serial reads and motion-completion waits, connection cleanup,
  per-instance read flags, and failed-transmission propagation on the joint example
  path. Write errors no longer automatically reconnect and replay a control frame.
- Kept CAN encoding, robot geometry values and parameter-map values unchanged.
  Retained original matrix helper attribution and its MIT license notice.
- Added offline regression tests (`python -m unittest discover -s tests -v`).

Validation is limited to Python and mocked transport. No hardware validation or
full audit of the retained advanced control functions is claimed. Use one caller
per serial connection; request/response identity matching has not been added.
