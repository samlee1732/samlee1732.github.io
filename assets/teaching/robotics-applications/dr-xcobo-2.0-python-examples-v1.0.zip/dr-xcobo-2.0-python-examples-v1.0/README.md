# DR-xcobo 2.0 — Python Driver Examples

Version 1.0 · SenseDex Lab course resources

[English instructions](README_EN.md)

用于《机器人学及应用》课程的 Python 串口驱动与示例。基于提供的 `robot.zip`
整理，保留原驱动的运动学、参数表和 CAN 指令格式。入口统一使用 `dr_xcobo`
包名，并将原来混在 `test.py` 里的操作拆为独立示例。

## 1. 环境与连接

- Python 3.8 或更新版本，依赖 `pyserial==3.5`。
- 使用 DR-xcobo 2.0 配套 USB-to-CAN 串口适配器，连接并给机械臂上电。
- 六个机械臂关节 ID 默认是 1–6；可选手爪 ID 是 7。
- 默认波特率 115200，必须与适配器实际配置一致。
- 这是直接连接实机的 Python 代码，不是 ROS 功能包，也不是 RViz 仿真。
  无需 `catkin_make`、`colcon build` 或 `source /opt/ros/.../setup.bash`。

在 Ubuntu 中，解压后进入本文件所在目录执行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m serial.tools.list_ports
```

若系统提示缺少 venv，先运行 `sudo apt install python3-venv`。
每次新开终端，进入此目录后只需重新执行 `source .venv/bin/activate`；
依赖安装一次即可。这一步激活 Python 环境，与 ROS 的 `source` 不同。

串口可能是 `/dev/ttyACM0` 或 `/dev/ttyUSB0`，请按列表中的实际端口填写。
Windows 端口名形如 `COM3`；运行前同样需要安装 Python、依赖和适配器驱动。

Ubuntu 如提示串口权限不足，检查该设备所属组。若为 `dialout`，执行：

```bash
sudo usermod -aG dialout "$USER"
```

注销并重新登录后生效。不要让其他程序同时占用同一串口。

## 2. 读取状态

```bash
python -m examples.read_state --port /dev/ttyACM0
```

显示六个电机角度、换算后的模型关节角，以及由关节角计算的末端位姿。
构造和此示例只发送查询，不写角度范围、PID 或位置控制命令。
任何一个关节读取失败都会报告错误，不会用默认零位冒充实际位置。

长度单位为 mm，质量为 kg，关节角度为度。未安装附加工具时，工具参数默认为 0。
若使用原示例中的工具配置，可显式指定以下值；须先与实物核对：

```bash
python -m examples.read_state --port /dev/ttyACM0 \
  --tool-length 138 --tool-center 69 --payload 0.916
```

## 3. 关节目标示例

先预览指令。此命令不打开串口，也不控制机器人：

```bash
python -m examples.move_joints --angles 0 90 0 0 0 0 --speed 1
```

参数是六个**模型关节角**，不是电机原始角度；`--speed` 是最大关节输出转速，单位 rpm。
以上目标仅作格式示例，不代表适合所有初始姿态与安装环境。
教师核对零位、关节限位、工具及运动空间后，添加 `--execute` 才发送实机指令：

```bash
python -m examples.move_joints --port /dev/ttyACM0 \
  --angles 0 90 0 0 0 0 --speed 1 --execute
```

串口断开或关闭程序**不等于停止运动**，实机运行时应能操作硬件急停。
示例只报告指令发送结果，不声称机器人已经到位。

## 4. 文件与接口

```text
dr_xcobo/                  驱动、运动学、手爪、参数表和矩阵工具
examples/read_state.py     关节状态与计算位姿示例
examples/move_joints.py    目标预览及显式实机发送示例
requirements.txt          Python 依赖
README.md / README_EN.md  中英文使用说明
CHANGELOG.md              整理与修改记录
```

从包导入：`from dr_xcobo import RobotArm`。
类仍支持原来的 `read_joints()`、`servo_to_model()`、`set_arm_joints()` 等方法。
使用 `with RobotArm(...) as robot:` 可在退出时关闭串口。
原 `range_init()` 仍会写硬件配置；仅在明确需要配置关节范围时调用。
旧轨迹接口需要显式 `calibrate_timing()`，此方法会发送当前位置保持命令；
不用于上面的入门示例。

## 验证范围与来源

已进行 Python 语法、导入、命令行和模拟串口测试；**未连接真实机械臂验证**。
源码保留了原驱动较多高级功能，它们未做完整硬件验证，不属于入门示例范围。
本包不包含原档案中的缓存文件、本机容器脚本、私人路径或账户备注。
驱动来源为课程提供的代码，未为原驱动添加新的授权声明；`umatrix.py`
保留 Jamie Lawson / micro-linalg 的原 MIT 许可与版权声明。

串口参考：[pySerial API](https://pyserial.readthedocs.io/en/latest/pyserial_api.html)
和[串口枚举工具](https://pyserial.readthedocs.io/en/latest/tools.html#serial.tools.list_ports)。
