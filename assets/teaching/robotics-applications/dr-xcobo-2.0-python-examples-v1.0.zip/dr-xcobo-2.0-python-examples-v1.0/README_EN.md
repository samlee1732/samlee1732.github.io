# DR-xcobo 2.0 — Python Driver Examples

Version 1.0 · [中文说明](README.md)

Course-provided serial driver and examples for Robotics and Applications.
Requires Python 3.8+ and `pyserial==3.5`. Connect the matching USB-to-CAN adapter
and power the robot. Joint IDs default to 1–6; the optional gripper uses ID 7.
The default baud rate is 115200 and must match the adapter.

This is a direct hardware interface, independent of ROS. It does not require
`catkin_make`, `colcon build`, ROS setup files or RViz.

## Install and find the port

In Ubuntu, extract the ZIP and open a terminal in the extracted directory:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m serial.tools.list_ports
```

Install `python3-venv` with apt if needed. In each new terminal, change to this
directory and activate `.venv` again; do not reinstall dependencies each time.
Choose the actual device, such as `/dev/ttyACM0` or `/dev/ttyUSB0` (Windows: `COM3`).
If an Ubuntu serial device belongs to `dialout` and access is denied, run
`sudo usermod -aG dialout "$USER"`, then log out and back in. Only one program
should use the port at a time.

## Read joint state

```bash
python -m examples.read_state --port /dev/ttyACM0
```

Prints motor angles, model joint angles and the pose calculated from those angles.
Construction and this example send queries only; they do not configure limits,
write PID parameters or send position commands. A failed joint read is an error,
not a substitute zero position.

Tool dimensions default to zero. For the tool configuration in the supplied
example, verify the physical setup before using these values:

```bash
python -m examples.read_state --port /dev/ttyACM0 \
  --tool-length 138 --tool-center 69 --payload 0.916
```

Lengths are in mm, mass in kg, and angles in degrees.

## Preview and send a joint target

This preview opens no serial connection and sends no command:

```bash
python -m examples.move_joints --angles 0 90 0 0 0 0 --speed 1
```

Angles are **model joint angles**, not raw motor angles. Speed is the maximum
joint output speed in rpm. This target illustrates syntax; it is not suitable
for every installation or initial pose. After an instructor checks calibration,
joint limits, tooling and clearance, explicitly enable hardware execution:

```bash
python -m examples.move_joints --port /dev/ttyACM0 \
  --angles 0 90 0 0 0 0 --speed 1 --execute
```

Closing the serial port does not stop ongoing motion. Keep the hardware emergency
stop accessible. The example reports command transmission, not verified arrival.

## API and scope

`from dr_xcobo import RobotArm` exposes the supplied robot API, including
`read_joints()`, `servo_to_model()` and `set_arm_joints()`.
Use `with RobotArm(...) as robot:` to close the serial connection on exit.
Explicit `range_init()` still writes hardware configuration.
Legacy timed trajectory functions require `calibrate_timing()`, which sends
current-position hold commands; it is not needed by these introductory examples.

The `dr_xcobo/` folder contains the driver, kinematics, gripper, parameter table
and matrix helper. `examples/` contains the two runnable examples. See
`CHANGELOG.md` for changes from the supplied archive.

Validation covers syntax, imports, CLI behavior and mocked serial communication.
**No physical robot testing has been performed.** The retained advanced driver
functions are outside the scope of the introductory examples and are not fully
hardware-validated. Local container scripts, caches and personal environment
notes are excluded. Existing source attribution is retained; the original MIT
notice in `umatrix.py` remains intact. No new license is assigned to the original
driver code.

Serial reference: [pySerial API](https://pyserial.readthedocs.io/en/latest/pyserial_api.html)
and [port tools](https://pyserial.readthedocs.io/en/latest/tools.html#serial.tools.list_ports).
