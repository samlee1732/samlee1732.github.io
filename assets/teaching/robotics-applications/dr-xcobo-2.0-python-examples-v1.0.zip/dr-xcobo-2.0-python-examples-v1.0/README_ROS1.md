# ROS 1 Noetic 容器

此环境使用官方 `ros:noetic-ros-base-focal` 镜像，包含 Ubuntu 20.04 和 ROS 1 Noetic 基础工具。主机仍使用 Ubuntu 24.04 和 ROS 2 Jazzy。

## 进入环境

在本目录打开终端：

```bash
./ros1.sh
```

进入后自动加载 ROS 1 和已编译的 catkin 工作空间。可以运行：

```bash
rosversion -d
roscore
```

需要多个 ROS 终端时，在每个主机终端分别运行 `./ros1.sh`。输入 `exit` 退出当前终端。

也可以直接从主机执行容器内的命令：

```bash
./ros1.sh rosversion -d
./ros1.sh catkin_make
```

## 工作空间和文件

- 主机：`/home/sen/Documents/Daran_ws/catkin_ws`
- 容器内：`/home/ros/catkin_ws`

两个路径对应同一个目录。将 ROS 1 功能包放在主机工作空间的 `src/` 下，在容器内运行 `catkin_make`，然后重新进入环境或执行 `source devel/setup.bash`。

容器中的日常命令使用与主机相同的用户 ID，编译结果由主机用户拥有。软件安装等管理操作可以通过 `docker exec --user root -it daran-ros1 bash` 执行。

## 启停

```bash
docker stop daran-ros1
```

`./ros1.sh` 会在下次使用时自动启动容器。此容器未设置开机自动启动。

## 当前范围

安装的是基础 ROS 1 环境。厂家 `dr_robot_object_follower` 源码、RealSense 驱动、`rqt_image_view`、图形显示和 USB/串口映射尚未配置；截图中的完整视觉抓取流程需要后续补齐这些内容。

ROS 1 Noetic 已于 2025 年 5 月结束官方维护，此环境用于运行旧项目。容器通过主机网络供本机 ROS 终端通信。
