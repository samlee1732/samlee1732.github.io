"""DR XCOBO 2.0 Python driver examples. Importing opens no serial port."""

from .arm_robot import arm_robot

RobotArm = arm_robot
__version__ = "1.0.0"

__all__ = ["RobotArm", "arm_robot", "__version__"]
