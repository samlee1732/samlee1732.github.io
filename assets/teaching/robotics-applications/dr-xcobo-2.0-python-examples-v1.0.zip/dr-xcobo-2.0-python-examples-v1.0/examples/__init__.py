"""DR-xcobo 2.0 teaching examples; importing this package does not connect hardware."""
