"""Shared command-line options / 通用连接参数。"""

import argparse
import math


def positive_float(value):
    result = float(value)
    if not math.isfinite(result) or result <= 0:
        raise argparse.ArgumentTypeError("Use a finite number greater than zero.")
    return result


def nonnegative_float(value):
    result = float(value)
    if not math.isfinite(result) or result < 0:
        raise argparse.ArgumentTypeError("Use a finite number of zero or greater.")
    return result


def connection_options(parser):
    parser.add_argument("--port", help="Serial device, e.g. /dev/ttyACM0 or COM3")
    parser.add_argument("--baudrate", type=int, default=115200)
    # Tool values are explicit: no assumption about the installed gripper.
    # 默认值表示未附加工具；安装手爪时按实物修改这些参数。
    parser.add_argument("--tool-length", type=nonnegative_float, default=0.0,
                        help="Tool reference point distance from joint 6, mm")
    parser.add_argument("--tool-center", type=nonnegative_float, default=0.0,
                        help="Tool center-of-mass distance from joint 6, mm")
    parser.add_argument("--payload", type=nonnegative_float, default=0.0,
                        help="Payload mass, kg")


def open_robot(args):
    # Importing is passive. Only this explicit call opens the serial port.
    from dr_xcobo import RobotArm
    return RobotArm(com=args.port, uart_baudrate=args.baudrate,
                    L_p=args.tool_length, L_p_mass_center=args.tool_center,
                    G_p=args.payload)
