"""Preview or send one joint target / 预览或发送一组关节目标角。"""

import argparse
import math
import sys

from .common import connection_options, open_robot, positive_float


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    connection_options(parser)
    parser.add_argument("--angles", nargs=6, type=float, required=True,
                        metavar=("J1", "J2", "J3", "J4", "J5", "J6"),
                        help="Six model joint angles in degrees")
    parser.add_argument("--speed", type=positive_float, default=1.0,
                        help="Maximum joint output speed in rpm (default: 1.0)")
    parser.add_argument("--execute", action="store_true",
                        help="Connect to the real robot and send the target")
    args = parser.parse_args(argv)
    if not all(math.isfinite(angle) for angle in args.angles):
        parser.error("All joint angles must be finite numbers")
    if args.speed > 30:
        parser.error("--speed must not exceed the supplied driver's 30 rpm limit")
    if args.baudrate <= 0:
        parser.error("--baudrate must be greater than zero")
    # Import constants without constructing a robot or opening a port.
    from dr_xcobo.arm_robot import max_list_temp, min_list_temp
    for joint, (angle, lower, upper) in enumerate(
            zip(args.angles, min_list_temp, max_list_temp), start=1):
        if not lower <= angle <= upper:
            parser.error(f"Joint {joint}: {angle} is outside [{lower}, {upper}] degrees")
    print(f"Model joint target (deg): {args.angles}; maximum speed: {args.speed} rpm")
    if not args.execute:
        print("Preview only: no serial connection or motion command. Add --execute to send.")
        return 0
    if not args.port:
        parser.error("--port is required with --execute")
    try:
        with open_robot(args) as robot:
            # Only this call sends a motion command. Run under instructor supervision.
            # 此处才发送运动指令；实机运行前由教师确认零位、工具与运动空间。
            if robot.set_arm_joints(angle_list=args.angles, speed=args.speed) is False:
                raise RuntimeError("The driver rejected or failed to send the joint target.")
            print("Command sent; physical completion has not been verified.")
            print("Closing the serial connection does not stop an ongoing motion.")
    except (OSError, ValueError, RuntimeError) as error:
        print(f"Command failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
