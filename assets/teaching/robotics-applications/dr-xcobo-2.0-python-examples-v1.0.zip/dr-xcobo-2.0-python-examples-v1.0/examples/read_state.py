"""Read joint angles and calculate the pose / 读取关节角度并计算位姿。"""

import argparse
import json
import sys

from .common import connection_options, open_robot


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    connection_options(parser)
    args = parser.parse_args(argv)
    if not args.port:
        parser.error("--port is required; list ports with python -m serial.tools.list_ports")
    if args.baudrate <= 0:
        parser.error("--baudrate must be greater than zero")
    try:
        with open_robot(args) as robot:
            motor_angles = robot.read_joints()
            if motor_angles is False:
                raise RuntimeError("Could not read all six joints; check power, port and joint IDs.")
            model_angles = robot.servo_to_model(motor_angles)
            robot.forward_kinematics_pose(model_angles)
            print(json.dumps({
                "motor_angles_deg": motor_angles,
                "model_joint_angles_deg": model_angles,
                "calculated_position_mm": robot.pl,
                "calculated_pitch_yaw_roll_deg": robot.theta_P_Y_R,
            }, indent=2))
    except (OSError, ValueError, RuntimeError) as error:
        print(f"Read failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
