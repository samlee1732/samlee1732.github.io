#!/usr/bin/env bash
# Enter the persistent ROS 1 container, or run a command inside it.
set -euo pipefail

container=daran-ros1
if ! docker container inspect "$container" >/dev/null 2>&1; then
    echo "ROS 1 container '$container' is missing." >&2
    exit 1
fi
docker start "$container" >/dev/null

terminal_flags=(-i)
if [[ -t 0 && -t 1 ]]; then
    terminal_flags=(-it)
fi

if [[ $# -eq 0 ]]; then
    exec docker exec "${terminal_flags[@]}" --user "$(id -u):$(id -g)" \
        --env HOME=/home/ros --workdir /home/ros/catkin_ws \
        "$container" /bin/bash -i
fi

exec docker exec "${terminal_flags[@]}" --user "$(id -u):$(id -g)" \
    --env HOME=/home/ros --workdir /home/ros/catkin_ws \
    "$container" /bin/bash -c '
        source /opt/ros/noetic/setup.bash
        if [[ -f /home/ros/catkin_ws/devel/setup.bash ]]; then
            source /home/ros/catkin_ws/devel/setup.bash
        fi
        exec "$@"
    ' bash "$@"
