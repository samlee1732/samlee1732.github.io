"""CLI regression tests. No hardware or serial port is opened."""

import contextlib
import io
import unittest
from unittest.mock import MagicMock, patch

from examples import move_joints, read_state


class ExampleTests(unittest.TestCase):
    def quiet(self, main, args):
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            return main(args)

    @patch("serial.Serial", side_effect=AssertionError("Hardware access in preview"))
    def test_preview_does_not_open_serial(self, serial):
        self.assertEqual(self.quiet(move_joints.main,
                                   ["--angles", "0", "90", "0", "0", "0", "0"]), 0)
        serial.assert_not_called()

    @patch("examples.move_joints.open_robot")
    def test_invalid_targets_never_connect(self, open_robot):
        cases = [
            ["--angles", "nan", "90", "0", "0", "0", "0"],
            ["--angles", "999", "90", "0", "0", "0", "0"],
            ["--angles", "0", "90", "0", "0", "0", "0", "--speed", "0"],
            ["--angles", "0", "90", "0", "0", "0", "0", "--speed", "inf"],
            ["--angles", "0", "90", "0", "0", "0", "0", "--execute"],
        ]
        for args in cases:
            with self.subTest(args=args), self.assertRaises(SystemExit) as raised:
                self.quiet(move_joints.main, args)
            self.assertEqual(raised.exception.code, 2)
        open_robot.assert_not_called()

    @patch("examples.move_joints.open_robot")
    def test_explicit_motion_sends_one_target(self, open_robot):
        robot = open_robot.return_value.__enter__.return_value
        robot.set_arm_joints.return_value = True
        result = self.quiet(move_joints.main, ["--port", "MOCK", "--angles", "0", "90",
                                              "0", "0", "0", "0", "--execute"])
        self.assertEqual(result, 0)
        robot.set_arm_joints.assert_called_once_with(angle_list=[0, 90, 0, 0, 0, 0], speed=1.0)
        open_robot.return_value.__exit__.assert_called_once()

    @patch("examples.move_joints.open_robot")
    def test_failed_transmission_returns_nonzero(self, open_robot):
        open_robot.return_value.__enter__.return_value.set_arm_joints.return_value = False
        result = self.quiet(move_joints.main, ["--port", "MOCK", "--angles", "0", "90",
                                              "0", "0", "0", "0", "--execute"])
        self.assertEqual(result, 1)
        open_robot.return_value.__exit__.assert_called_once()

    @patch("examples.read_state.open_robot")
    def test_read_failure_returns_nonzero_and_closes(self, open_robot):
        robot = open_robot.return_value.__enter__.return_value
        robot.read_joints.return_value = False
        self.assertEqual(self.quiet(read_state.main, ["--port", "MOCK"]), 1)
        robot.forward_kinematics_pose.assert_not_called()
        open_robot.return_value.__exit__.assert_called_once()

    @patch("examples.read_state.open_robot")
    def test_zero_angles_are_valid_state(self, open_robot):
        robot = open_robot.return_value.__enter__.return_value
        robot.read_joints.return_value = [0.0] * 6
        robot.servo_to_model.return_value = [0, 90, 0, 0, 0, 0]
        robot.pl = [0, -45, 503.5]
        robot.theta_P_Y_R = [90, 0, 0]
        self.assertEqual(self.quiet(read_state.main, ["--port", "MOCK"]), 0)
        robot.set_arm_joints.assert_not_called()
        robot.forward_kinematics_pose.assert_called_once_with([0, 90, 0, 0, 0, 0])


if __name__ == "__main__":
    unittest.main()
