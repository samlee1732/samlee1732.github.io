"""High-level regression checks. Every hardware entry point is mocked."""

import importlib
import unittest
from contextlib import ExitStack
from unittest.mock import Mock, patch

from dr_xcobo import RobotArm


robot_module = importlib.import_module("dr_xcobo.arm_robot")


class RobotTests(unittest.TestCase):
    def setUp(self):
        self.patches = ExitStack()
        self.addCleanup(self.patches.close)
        # This guard ensures an accidentally unmocked constructor cannot open a port.
        self.serial = self.patches.enter_context(
            patch("serial.Serial", side_effect=AssertionError("Hardware access forbidden"))
        )
        self.patches.enter_context(patch.object(robot_module.time, "sleep"))
        self.patches.enter_context(patch.object(robot_module.gripper.gripper, "__init__", return_value=None))
        self.read = self.patches.enter_context(
            patch.object(RobotArm, "read_joints", return_value=[0.0, 90.0, 0.0, 0.0, 0.0, 0.0])
        )
        self.fk = self.patches.enter_context(patch.object(RobotArm, "forward_kinematics_pose"))
        self.send = self.patches.enter_context(patch.object(RobotArm, "set_angles", return_value=True))
        self.ranges = self.patches.enter_context(patch.object(RobotArm, "set_angle_range", return_value=True))
        self.close = self.patches.enter_context(patch.object(RobotArm, "close"))

    def test_constructor_only_reads_and_sets_host_state(self):
        arm = RobotArm(com="mock")
        self.assertEqual(arm.c_angle_list, [0.0] * 6)
        self.assertEqual(arm.bit_time, 0)
        self.read.assert_called_once_with()
        self.send.assert_not_called()
        self.ranges.assert_not_called()
        self.close.assert_not_called()
        self.serial.assert_not_called()

    def test_constructor_failure_closes_and_raises(self):
        self.read.return_value = False
        with self.assertRaisesRegex(RuntimeError, "read all six joints"):
            RobotArm(com="mock")
        self.close.assert_called_once_with()
        self.send.assert_not_called()
        self.ranges.assert_not_called()

    def test_constructor_model_error_closes_and_raises(self):
        self.fk.side_effect = ValueError("bad feedback")
        with self.assertRaisesRegex(ValueError, "bad feedback"):
            RobotArm(com="mock")
        self.close.assert_called_once_with()

    def test_mutable_state_is_per_instance(self):
        first, second = RobotArm(com="mock"), RobotArm(com="mock")
        for name in (
            "c_angle_list", "pose_list", "servo_angle_list_list", "pose_list_servo",
            "pose_list_temp", "ID_list", "P1_list", "P2_list", "MAX_list", "MIN_list",
            "init_model_angle", "tutorial_t_list", "torque_limits", "torque_factors",
        ):
            with self.subTest(name=name):
                self.assertIsNot(getattr(first, name), getattr(second, name))
        first.pose_list[0][0] = 12
        first.ID_list[0] = 50
        self.assertEqual(second.pose_list[0][0], 0)
        self.assertEqual(second.ID_list[0], 1)

    def test_explicit_range_configuration_still_writes(self):
        arm = RobotArm(com="mock")
        arm.range_init([10] * 6, [-10] * 6)
        self.assertEqual(self.ranges.call_count, 6)

    def test_timed_trajectories_require_explicit_calibration_before_motion(self):
        arm = RobotArm(com="mock")
        for invoke in (arm.set_arm_poses, arm.set_arm_poses_curve_do, arm.tutorial_do):
            with self.subTest(method=invoke.__name__):
                with self.assertRaisesRegex(RuntimeError, "calibrate_timing"):
                    invoke()
        self.send.assert_not_called()

    def test_calibration_is_explicit_and_uses_measured_interval(self):
        arm = RobotArm(com="mock")
        with patch.object(robot_module.time, "perf_counter", side_effect=[10.0, 10.06]):
            self.assertAlmostEqual(arm.calibrate_timing(samples=3), 0.02)
        self.assertEqual(self.send.call_count, 4)
        self.assertAlmostEqual(arm.bit_time, 0.02)

    def test_failed_calibration_remains_uncalibrated(self):
        arm = RobotArm(com="mock")
        self.send.return_value = False
        with self.assertRaisesRegex(RuntimeError, "hold command failed"):
            arm.calibrate_timing()
        self.assertEqual(arm.bit_time, 0)

    def test_empty_or_invalid_duration_trajectory_is_rejected(self):
        arm = RobotArm(com="mock")
        arm.bit_time = 0.01
        with self.assertRaisesRegex(ValueError, "nonempty"):
            arm.set_arm_poses_curve_do()
        for duration in (0, -1, float("nan"), float("inf")):
            with self.subTest(duration=duration):
                with self.assertRaises(ValueError):
                    arm.set_arm_poses(t=duration)
        self.send.assert_not_called()

    def test_joint_move_translates_model_angles_and_reports_send_success(self):
        arm = RobotArm(com="mock")
        self.assertTrue(arm.set_arm_joints([0, 10, 0, 0, 0, 0], speed=1))
        self.send.assert_called_once_with([1, 2, 3, 4, 5, 6], [0, 80, 0, 0, 0, 0], 1, 10, 1)

    def test_joint_move_reports_transport_failure(self):
        arm = RobotArm(com="mock")
        self.send.return_value = False
        self.assertFalse(arm.set_arm_joints([0] * 6))

    def test_joint_move_reports_transport_exception(self):
        arm = RobotArm(com="mock")
        self.send.side_effect = OSError("mock disconnect")
        self.assertFalse(arm.set_arm_joints([0] * 6))


class ReadJointsTests(unittest.TestCase):
    def make_arm(self):
        arm = object.__new__(RobotArm)
        arm.ID_list = [1, 2, 3, 4, 5, 6]
        arm.clear_uart = Mock()
        return arm

    def test_zero_degree_feedback_is_valid(self):
        arm = self.make_arm()
        arm.get_angle = Mock(return_value=0.0)
        self.assertEqual(arm.read_joints(), [0.0] * 6)
        self.assertEqual(arm.get_angle.call_count, 6)

    def test_failed_feedback_retries_without_confusing_zero_with_false(self):
        arm = self.make_arm()
        arm.get_angle = Mock(side_effect=[False, 0.0] + [0.0] * 5)
        self.assertEqual(arm.read_joints(), [0.0] * 6)
        self.assertEqual(arm.get_angle.call_count, 7)

    def test_persistent_failure_preserves_false_sentinel(self):
        arm = self.make_arm()
        arm.get_angle = Mock(return_value=False)
        self.assertIs(arm.read_joints(), False)
        self.assertEqual(arm.get_angle.call_count, 12)


if __name__ == "__main__":
    unittest.main()
