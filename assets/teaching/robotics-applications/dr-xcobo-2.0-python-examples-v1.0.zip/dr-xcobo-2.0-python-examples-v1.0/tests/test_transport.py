"""Transport regression tests. All serial connections are replaced with fakes."""

import importlib
import math
import unittest
from unittest.mock import patch

import serial

from dr_xcobo import dr_empower_can as transport
from dr_xcobo.arm_six_axis import arm


class FakeClock:
    def __init__(self):
        self.now = 0.0

    def monotonic(self):
        return self.now

    def sleep(self, duration):
        self.now += duration


class FakeSerial:
    def __init__(self, clock, data=b""):
        self.clock = clock
        self.data = bytearray(data)
        self.timeout = 0.05
        self.write_timeout = 0.05
        self.closed = False
        self.writes = []

    def read(self, size=1):
        if not self.data:
            self.clock.sleep(self.timeout)
            return b""
        self.clock.sleep(min(0.0001, self.timeout))
        result = bytes(self.data[:size])
        del self.data[:size]
        return result

    def write(self, data):
        self.writes.append(bytes(data))
        return len(data)

    def close(self):
        self.closed = True


def frame(node=1, payload=b"\0" * 8):
    """Vendor 16-byte USB-CAN envelope, with original ID layout."""
    identifier = (node << 5) + 1
    return bytes([0xAA, 0, 0, 8, 0, 0, identifier >> 8, identifier & 255]) + payload


class TransportTests(unittest.TestCase):
    def setUp(self):
        self.clock = FakeClock()
        self.connections = []

        def serial_factory(*args, **kwargs):
            connection = FakeSerial(self.clock)
            connection.timeout = kwargs["timeout"]
            connection.write_timeout = kwargs["write_timeout"]
            self.connections.append(connection)
            return connection

        self.serial_patch = patch.object(serial, "Serial", side_effect=serial_factory)
        self.serial_constructor = self.serial_patch.start()
        self.addCleanup(self.serial_patch.stop)
        for name in ("monotonic", "sleep"):
            patcher = patch.object(transport.time, name, getattr(self.clock, name))
            patcher.start()
            self.addCleanup(patcher.stop)

    def driver(self, data=b""):
        result = transport.DrEmpower_can(com="MOCK", timeout=0.05)
        result.uart.data.extend(data)
        return result

    def test_import_never_opens_a_port(self):
        importlib.reload(transport)
        self.serial_constructor.assert_not_called()

    def test_constructor_has_finite_read_and_write_timeouts(self):
        self.driver()
        self.serial_constructor.assert_called_once_with(
            "MOCK", 115200, timeout=0.05, write_timeout=0.05
        )

    def test_invalid_configuration_does_not_open_port(self):
        for timeout in (0, -1, math.inf, math.nan):
            with self.subTest(timeout=timeout), self.assertRaises(ValueError):
                transport.DrEmpower_can(com="MOCK", timeout=timeout)
        with self.assertRaises(ValueError):
            transport.DrEmpower_can()
        self.serial_constructor.assert_not_called()

    def test_empty_garbage_and_partial_reads_have_one_deadline(self):
        for data in (b"", b"garbage", frame()[:10], b"x" * 1000):
            for method, args in (("read_data", ()), ("read_data_state", (1,)),
                                 ("read_data_state2", (1,)), ("read_data_id", ())):
                with self.subTest(data_length=len(data), method=method):
                    driver = self.driver(data)
                    start = self.clock.now
                    with self.assertRaises(TimeoutError):
                        getattr(driver, method)(*args)
                    self.assertLessEqual(self.clock.now - start, 0.050001)
                    self.assertEqual(driver.READ_FLAG, -1)
                    self.assertEqual(driver.uart.timeout, 0.05)

    def test_read_discards_leading_noise_and_preserves_next_frame(self):
        first, second = frame(1), frame(2)
        driver = self.driver(b"noise" + first + second)
        self.assertEqual(driver.read_data(), list(first))
        self.assertEqual(driver.READ_FLAG, 1)
        self.assertEqual(bytes(driver.uart.data), second)

    def test_state_read_consumes_only_requested_frames(self):
        frames = frame(1) + frame(2) + frame(3)
        driver = self.driver(frames)
        self.assertEqual(driver.read_data_state(2), list(frames[:32]))
        self.assertEqual(bytes(driver.uart.data), frames[32:])

    def test_id_scan_collects_complete_responses_within_deadline(self):
        driver = self.driver(frame(1) + frame(7))
        self.assertEqual(driver.read_data_id(), [1, 7])
        self.assertLessEqual(self.clock.now, 0.050001)
        self.assertEqual(driver.READ_FLAG, 1)

    def test_read_status_is_isolated_per_connection(self):
        first = self.driver(frame())
        second = self.driver()
        first.read_data()
        with self.assertRaises(TimeoutError):
            second.read_data()
        self.assertEqual(first.READ_FLAG, 1)
        self.assertEqual(second.READ_FLAG, -1)
        first.cur_angle_list.append(0)
        self.assertEqual(second.cur_angle_list, [])

    def test_invalid_frame_does_not_raise_index_error(self):
        driver = self.driver()
        self.assertEqual(driver.uart_to_can([]), [])
        self.assertEqual(driver.READ_FLAG, -1)

    def test_zero_angle_is_a_valid_property_value(self):
        # 38001 is the existing output-shaft angle property address.
        payload = bytes([0x71, 0x94, 0, 0, 0, 0, 0, 0])
        driver = self.driver(frame(payload=payload))
        result = driver.get_angle(id_num=1)
        self.assertEqual(result, 0.0)
        self.assertIsNot(result, False)
        self.assertEqual(driver.READ_FLAG, 1)

    def test_property_read_failure_returns_false_without_process_exit(self):
        driver = self.driver()
        self.assertIs(driver.get_angle(id_num=1), False)
        self.assertEqual(driver.READ_FLAG, -1)

    def test_invalid_property_clears_previous_read_status(self):
        driver = self.driver(frame())
        driver.read_data()
        self.assertIs(driver.read_property(property="missing"), False)
        self.assertEqual(driver.READ_FLAG, -1)

    def test_position_done_distinguishes_zero_from_failure(self):
        driver = self.driver()
        with patch.object(driver, "read_property", side_effect=[0, 1]) as read:
            self.assertTrue(driver.position_done(id_num=1))
            self.assertEqual(read.call_count, 2)
        with patch.object(driver, "read_property", return_value=False) as read:
            self.assertFalse(driver.position_done(id_num=1))
            self.assertEqual(read.call_count, 1)

    def test_position_wait_timeout_is_finite(self):
        driver = self.driver()
        with patch.object(driver, "read_property", return_value=0):
            self.assertFalse(driver.position_done(id_num=1, timeout=0.03))
        self.assertLessEqual(self.clock.now, 0.030001)

    def test_failed_write_is_not_replayed_or_reconnected(self):
        driver = self.driver()
        with patch.object(driver.uart, "write", side_effect=serial.SerialTimeoutException("test")) as write:
            with self.assertRaises(serial.SerialTimeoutException):
                driver.write_data([0] * 16)
            write.assert_called_once()
        self.assertEqual(self.serial_constructor.call_count, 1)
        self.assertFalse(driver.uart.closed)

    def test_context_manager_closes_on_exception(self):
        driver = self.driver()
        with self.assertRaisesRegex(RuntimeError, "test"):
            with driver as entered:
                self.assertIs(entered, driver)
                raise RuntimeError("test")
        self.assertTrue(driver.uart.closed)
        driver.close()
        transport.DrEmpower_can.__new__(transport.DrEmpower_can).close()

    def test_arm_geometry_and_pose_are_isolated(self):
        first = arm(L_p=10, G_p=0.1, com="MOCK", timeout=0.05)
        second = arm(L_p=20, G_p=0.2, com="MOCK", timeout=0.05)
        self.assertEqual(first.L[4], 55)
        self.assertEqual(second.L[4], 65)
        self.assertEqual(arm.L[4], 45)
        self.assertEqual(len(first.G), 6)
        self.assertEqual(len(second.G), 6)
        self.assertEqual(len(arm.G), 5)
        for name in ("L", "G", "pl", "theta", "theta_P_Y_R", "pl_camera"):
            self.assertIsNot(getattr(first, name), getattr(second, name))
        first.theta[0] = 1
        self.assertEqual(second.theta[0], 0)

    def test_existing_can_and_scalar_encoding_is_preserved(self):
        driver = self.driver()
        payload = driver.format_data([1.0, -2, 300], "f s16 s16", "encode")
        self.assertEqual(payload, [0, 0, 128, 63, 254, 255, 44, 1])
        can = [8, 0, 33] + payload
        encoded = driver.can_to_uart(can)
        self.assertEqual(encoded, [0xAA, 0, 0, 8, 0, 0, 0, 33] + payload)
        self.assertEqual(driver.uart_to_can(encoded), can)


if __name__ == "__main__":
    unittest.main()
