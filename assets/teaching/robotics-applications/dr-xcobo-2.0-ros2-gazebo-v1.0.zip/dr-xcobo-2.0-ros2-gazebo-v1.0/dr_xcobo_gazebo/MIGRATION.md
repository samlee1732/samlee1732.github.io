# Migration record / 迁移记录

## Preserved source model / 保留的原模型

The source is the supplied `Dr_arm_6_desk` robot-description package and
`Dr_arm_6_desk_moveit` configuration package. This Gazebo package is a separate
ROS 2 derivative; the original packages and the separate ROS 2 mock package
were not modified.

- The ten STL files are byte-identical. `config/source_provenance.json` records
  their SHA-256 values and the original URDF/SRDF hashes.
- All ten original link names, nine original joint names, joint types, axes,
  origin transforms, visual/collision geometry and mesh scales are unchanged.
  Only the mesh URI package prefix becomes `package://dr_xcobo_gazebo/`.
- All original joint position bounds remain unchanged: `Joint1`–`Joint6`
  `[-3.14, 3.14]` rad; both finger joints `[0, 0.04]` m.
- All nine supplied link inertias are unchanged. The source SRDF is copied
  byte-for-byte; group `arm` remains the six-axis chain `base_link` → `Link6`.

源包为用户提供的 `Dr_arm_6_desk` 与 `Dr_arm_6_desk_moveit`，本包为独立 ROS 2
派生版本，原包与另一份 mock 示例均未修改。十个 STL 字节不变；原 link/joint 名、
类型、轴向、origin、视觉/碰撞几何、缩放与关节位置上下限不变；仅 mesh 的包名前缀
更新。原有九个 link 惯量不变，SRDF 按字节保留，`arm` 仍为六轴链。

## Simulation-only additions / 仅用于仿真的新增项

1. **World-fixed base.** A new empty `world` link and zero-transform fixed
   `world_to_base` joint anchor `base_link`. The entire robot is not static;
   the arm and finger joints remain movable. `Joint_Cam` receives
   `preserveFixedJoint=true` so its fixed joint and camera link survive URDF→SDF
   conversion as model entities.
2. **Missing base inertia.** The source `base_link` has no `<inertial>` element.
   A positive placeholder is necessary for Gazebo to retain the link and its
   downstream joints. We use a **1 kg uniform box**, size **0.45 × 0.35 × 0.103 m**,
   centered at **(-0.01175, 0, 0.0515) m**: the measured STL bounding-box center and
   dimensions, with an arbitrary mass. Diagonal inertia is
   **(0.0110924166667, 0.0177590833333, 0.0270833333333) kg·m²** and off-diagonal
   terms are zero. This is not a measured robot inertia. The base is world-fixed.
3. **Nonzero demo limits.** Original movable-joint effort and velocity entries
   are zero. Only the derived Xacro changes these to arm **5 N·m / 0.5 rad/s** and
   fingers **5 N / 0.02 m/s**. MoveIt adds acceleration limits **1 rad/s²** and
   **0.04 m/s²**, and default velocity/acceleration scaling **0.2**. None are
   hardware ratings or calibrated limits.
4. **Gazebo ros2_control.** `gz_ros2_control/GazeboSimSystem` replaces mock command
   mirroring. All eight movable joints expose a position command interface and
   position/velocity state interfaces. Initial arm positions are zero; fingers
   are 0.02 m each. The model plugin owns `/controller_manager` at **100 Hz**.
   Its position feedback gain **0.1** converts position error to a target velocity;
   it does not simulate a calibrated actuator or torque loop.
5. **Finger holding.** `finger_hold_controller` is a
   `position_controllers/JointGroupPositionController` that claims the two finger
   position interfaces. It keeps the commands initialized to 0.02 m. Before
   controllers activate, `hold_joints=true` sets unclaimed commanded joints to
   zero velocity; it is a startup fallback, not position-feedback holding.
6. **World and time.** The local SDF world supplies ground, light, gravity
   **-9.81 m/s²** and **0.001 s** physics steps. The clock bridge is exclusively
   Gazebo→ROS. ROS nodes and controllers use simulation time. The launch starts
   Gazebo playing and waits for successful model creation and controller
   activation before starting MoveIt/RViz.
7. **ROS 2 configuration.** The package uses ament_cmake, Python launch, current
   Jazzy OMPL adapter lists, KDL kinematics, RViz2 and the MoveIt simple controller
   manager. The arm's action is `/arm_controller/follow_joint_trajectory`. It does
   not include ROS 1 nodes, serial code or a selectable real-hardware backend.

中文对应说明：

1. 新增空 `world` link 与零变换固定关节 `world_to_base`，固定基座但不把整机设为
   static；保留原相机固定关节在 SDF 中的实体。
2. 原 `base_link` 缺失惯量，补充 **1 kg、0.45 × 0.35 × 0.103 m** 均匀箱体占位惯量。
   尺寸与质心来自 STL 包围盒，质量为任意演示值，不是真机测量值；基座固定到 world。
3. 原速度/effort 零值仅在派生副本改为上述演示值，位置限位不变；加速度与缩放同样
   仅用于教学，不代表真实硬件性能。
4. 后端改为 Gazebo 物理引擎及 `gz_ros2_control`，八个可动关节均有状态与位置命令
   接口。六轴初值 0，两指各 0.02 m。100 Hz 控制管理器由 Gazebo 插件创建。
   位置增益 0.1 通过误差生成速度指令，不是经过标定的电机/力矩模型。
5. 两指由独立位置控制器保持初始命令，MoveIt 只控制六轴。控制器激活前的
   `hold_joints` 为零速度保持后备方式，不是位置误差反馈。
6. SDF 提供地面、灯光、重力和 1 ms 仿真步长；单向桥接时钟，所有 ROS 节点/控制器
   使用仿真时间；模型生成和全部控制器激活成功后才启动 MoveIt/RViz。
7. 使用 ament_cmake/Python launch/MoveIt 2/RViz2，不含 ROS 1、串口或真机后端。

## Scope of evidence / 验证边界

The offline validator parses Xacro/XML/YAML/Python, checks meshes against source
hashes and tests model/controller consistency. With `--source-root`, it removes
only the documented additions, restores the documented URI/limit substitutions,
and compares the complete remaining XML tree to the original model. These checks
do **not** establish that ROS 2 startup, Gazebo contact dynamics, trajectory tracking
or rendering work on a particular machine. No ROS/Gazebo runtime was available
while this package was authored.

Gazebo objects are not automatically synchronized into MoveIt's collision scene.
The original CAD collision meshes remain unchanged; Gazebo's physics engine may
approximate them, and self/contact behavior has not been tuned or validated.
This example is not a verified digital twin or evidence of hardware-safe motion.

静态验证可核对格式、哈希、模型保真与控制配置，但不能证明实际 ROS/Gazebo 启动、
接触动力学、轨迹跟踪和渲染已经通过。本包尚未在 ROS/Gazebo 环境实跑。Gazebo
物体不会自动同步到 MoveIt 碰撞场景；原 CAD 碰撞网格在物理引擎中可能被近似，
碰撞/接触效果未调试验证，因此本例不是已验证的数字孪生或真机运动安全依据。

## Official references / 官方依据

- [Jazzy gz_ros2_control documentation](https://control.ros.org/jazzy/doc/gz_ros2_control/doc/index.html)
- [Official Jazzy position-control example](https://github.com/ros-controls/gz_ros2_control/blob/jazzy/gz_ros2_control_demos/urdf/test_cart_position.xacro.urdf)
- [Jazzy Gazebo position/holding implementation](https://github.com/ros-controls/gz_ros2_control/blob/jazzy/gz_ros2_control/src/gz_system.cpp)
- [Jazzy forward position-command controller](https://github.com/ros-controls/ros2_controllers/blob/jazzy/forward_command_controller/src/forward_controllers_base.cpp)
- [ros_gz_sim resource-path export](https://github.com/gazebosim/ros_gz/blob/jazzy/ros_gz_sim/README.md)
- [Harmonic ROS bridge directions](https://gazebosim.org/docs/harmonic/ros2_integration/)
- [SDFormat URDF fixed-joint conversion](https://sdformat.org/tutorials/specification/sdformat_urdf_extensions/1.6/)
- [MoveIt Jazzy OMPL configuration schema](https://github.com/moveit/moveit2/blob/jazzy/moveit_configs_utils/default_configs/ompl_planning.yaml)
