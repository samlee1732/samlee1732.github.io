# Attribution / 来源说明

The robot description, SRDF and ten STL assets come from the supplied
`Dr_arm_6_desk` and `Dr_arm_6_desk_moveit` ROS 1 packages. Their manifests declare
the license as `BSD`; that declaration is retained in this derived package.
The MoveIt source manifest identifies its author as `Dr_Robot`.

The original SolidWorks-to-URDF exporter attribution remains in the Xacro header.
The ROS 2/Gazebo configuration and bilingual documentation record the adaptation
explicitly; they do not change the source model's attribution. All ten mesh files
are unchanged. `config/source_provenance.json` records the source hashes.

This is an independent Gazebo teaching configuration using the supplied model.
Added simulation values are not manufacturer specifications or validated physical
measurements. No physical-robot driver is included.

机器人描述、SRDF 与十个 STL 来自用户提供的 `Dr_arm_6_desk` 和
`Dr_arm_6_desk_moveit` ROS 1 功能包。原 manifest 声明 `BSD`，派生包保留该声明；
原 MoveIt manifest 作者为 `Dr_Robot`。Xacro 头部保留 SolidWorks-to-URDF 导出器
原始署名，网格文件不变，源哈希记录于 `config/source_provenance.json`。

本包是使用该模型的独立 Gazebo 教学配置，新增仿真参数不代表制造商规格或经过验证
的物理测量值，不包含真机驱动。迁移细节与验证边界见 `MIGRATION.md`。
