# DR-xcobo 2.0 · Gazebo Harmonic + MoveIt 2

English first; 中文说明见下方。

A self-contained **Ubuntu 24.04 / ROS 2 Jazzy / Gazebo Harmonic** teaching package.
MoveIt plans the six-axis arm; Execute sends a trajectory to a Gazebo-backed
`joint_trajectory_controller`. This version uses Gazebo physics through
`gz_ros2_control/GazeboSimSystem`, not the separate mock-hardware demo.
It includes the original ten STL files and does not need another robot model
package, a physical robot, serial hardware, Gazebo Classic or ROS 1.

**Validation status:** XML, Xacro, YAML, Python syntax and configuration consistency
are checked offline, including source mesh hashes and preservation of the source
model. This package has **not been built or run in ROS 2 / Gazebo** on the authoring
computer. Runtime startup, rendering, contact behavior and controller tuning still
need verification on the target Ubuntu environment.

## Install and build

First install ROS 2 Jazzy Desktop on Ubuntu 24.04 using the
[official Ubuntu deb instructions](https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html).
The commands below assume that installation and its apt repository are ready.
Jazzy's ROS Gazebo packages supply the supported Harmonic pairing.

```bash
sudo apt update
sudo apt install unzip build-essential python3-yaml \
  python3-colcon-common-extensions \
  ros-jazzy-ament-cmake ros-jazzy-ament-cmake-test \
  ros-jazzy-moveit ros-jazzy-ros-gz \
  ros-jazzy-gz-ros2-control ros-jazzy-ros2-controllers \
  ros-jazzy-xacro
```

Extract the supplied archive and put this package directly in `src/`:

```text
~/dr_xcobo_gazebo_ws/src/dr_xcobo_gazebo/package.xml
```

For the downloadable archive, use:

```bash
mkdir -p ~/dr_xcobo_gazebo_ws/src
unzip ~/Downloads/dr-xcobo-2.0-ros2-gazebo-v1.0.zip \
  -d ~/Downloads/dr-xcobo-gazebo-unpacked
cp -R ~/Downloads/dr-xcobo-gazebo-unpacked/dr-xcobo-2.0-ros2-gazebo-v1.0/dr_xcobo_gazebo \
  ~/dr_xcobo_gazebo_ws/src/
cd ~/dr_xcobo_gazebo_ws
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install --packages-select dr_xcobo_gazebo
source install/setup.bash
ros2 launch dr_xcobo_gazebo gazebo.launch.py
```

In a fresh terminal after the first build:

```bash
source /opt/ros/jazzy/setup.bash
source ~/dr_xcobo_gazebo_ws/install/setup.bash
ros2 launch dr_xcobo_gazebo gazebo.launch.py
```

For a server-only check with both windows disabled:

```bash
ros2 launch dr_xcobo_gazebo gazebo.launch.py gui:=false rviz:=false
```

You can also disable either window separately. `gui:=false` still runs the Gazebo
physics server. `rviz:=false` still runs MoveIt. The world starts playing (`-r`).
Only run one copy of this example at a time in a ROS domain: its clock, controller
names and robot-description topics are global.

## Plan and execute

1. Wait for both Gazebo and RViz2. RViz starts only after model creation and all
   three controllers have succeeded. If the Gazebo view is distant, select the
   `dr_xcobo` model in its entity tree and use the view's focus action.
2. In RViz's MotionPlanning panel, use planning group **arm**. Keep the start state
   at the current robot state. Choose a small reachable goal using the end-effector
   interactive marker; begin above the ground and close to the current pose.
3. Click **Plan**. The translucent trajectory is a preview; the Gazebo robot has
   not executed it yet. Inspect the full path.
4. Click **Execute**. Observe the arm move in **Gazebo** and the current robot state
   update in RViz. The two fingers remain at **0.02 m each**; they are not part of
   the six-axis arm planning group. This package does not provide a gripper UI.
5. If Gazebo is paused, press its Play button before executing. Stop the launch
   with `Ctrl+C` in the terminal. After resetting the Gazebo world, restart the
   launch so controller time and state initialize together.

The Gazebo ground and added Gazebo objects **are not automatically inserted into
MoveIt's planning scene**. A successful plan therefore does not certify clearance
from those objects. Add matching collision objects in MoveIt before planning near
obstacles. This basic example includes no perception or scene-synchronization
bridge. The source's CAD collision meshes are retained; collision shape conversion
and contact behavior in Gazebo require target-machine verification.

## Configuration and checks

- `worlds/dr_xcobo.sdf`: ground, sunlight, gravity and 1 ms physics steps.
- `urdf/dr_xcobo.urdf.xacro`: source geometry plus a world-fixed base and the
  Gazebo ros2_control plugin. Xacro receives the installed controller-YAML path.
- `config/ros2_controllers.yaml`: 100 Hz controller manager;
  `joint_state_broadcaster` publishes all eight movable joints;
  `finger_hold_controller` claims the two finger position interfaces;
  `arm_controller` exposes the six-axis FollowJointTrajectory action.
- `config/moveit_controllers.yaml`: MoveIt maps only `arm_controller`.
- All ROS nodes/controllers use simulation time. `/clock` is bridged only from
  Gazebo to ROS. The Gazebo plugin creates controller_manager internally.

The fingers' position commands are seeded to 0.02 m in the Gazebo hardware plugin.
The position controller retains that command without needing a startup publisher.
Before activation, `hold_joints=true` applies zero-velocity holding to unclaimed
command interfaces. This fallback is not a position-feedback controller.

The original URDF's zero speed/effort entries were replaced only in this derived
model: arm **0.5 rad/s, 5 N·m**; fingers **0.02 m/s, 5 N**. MoveIt acceleration
limits are **1 rad/s²** and **0.04 m/s²**, with default scaling **0.2**. These and
the Gazebo position gain **0.1** are **demonstration values, not hardware ratings
or validated controller tuning**. The position interface generates velocity
commands from position error; this is not a calibrated motor/torque model.

Read [MIGRATION.md](MIGRATION.md) for the exact model changes and
[NOTICE.md](NOTICE.md) for attribution. To run the offline checks after installing
the listed dependencies:

```bash
python3 ~/dr_xcobo_gazebo_ws/src/dr_xcobo_gazebo/test/validate_static.py
cd ~/dr_xcobo_gazebo_ws
colcon test --packages-select dr_xcobo_gazebo
colcon test-result --verbose
```

For runtime diagnosis in another sourced terminal:

```bash
ros2 control list_controllers
ros2 topic echo /joint_states --once
ros2 topic echo /clock --once
```

Expect the broadcaster, finger hold controller and arm controller to be `active`,
eight joint names in `/joint_states`, and a progressing clock while Gazebo plays.
If spawning or activation fails, inspect the first process error; the launch
stops instead of opening MoveIt after a failed controller. If no model appears,
verify the workspace is sourced and the package's `meshes/` directory was installed.
Rendering problems can be isolated with `gui:=false rviz:=false`.

## 中文快速说明

这是独立的 **Ubuntu 24.04 / ROS 2 Jazzy / Gazebo Harmonic / MoveIt 2** 教学功能包。
MoveIt 规划六轴机械臂，Execute 通过轨迹控制器驱动 Gazebo 中的模型。
后端为 `gz_ros2_control/GazeboSimSystem`，包含重力、地面与物理引擎；与另一份
GenericSystem mock 示例不同。本包已包含相同的十个 STL，无需再下载 URDF 包，
无需真机或串口，也不使用 ROS 1、Gazebo Classic。

**验证范围：** 已做 XML、Xacro、YAML、Python 语法和配置一致性静态检查，
并比较原模型与网格哈希。编写本包的电脑没有 ROS/Gazebo，**尚未在 ROS 2 /
Gazebo 环境编译或运行**；启动、显示、接触行为与控制参数仍需在目标 Ubuntu
电脑上验证。

**安装与运行：** 先按上方官方链接安装 Jazzy Desktop 并配置软件源，再执行英文
“Install and build”中的 apt、解压、复制、colcon build 和 launch 命令。
包应位于 `~/dr_xcobo_gazebo_ws/src/dr_xcobo_gazebo/package.xml`。
首次构建后，每次新终端只需 source ROS 与工作空间，再运行：

```bash
source /opt/ros/jazzy/setup.bash
source ~/dr_xcobo_gazebo_ws/install/setup.bash
ros2 launch dr_xcobo_gazebo gazebo.launch.py
```

**操作步骤：** 等 Gazebo 与 RViz2 均出现，在 MotionPlanning 中选 `arm`，起点用当前
状态，先拖动末端标记选择近距离、地面上方的可达目标。点 **Plan** 查看半透明轨迹，
确认后点 **Execute**，在 Gazebo 观察实际仿真运动，RViz 同步显示当前关节状态。
两个夹指由独立 `finger_hold_controller` 保持各 **0.02 m**，不属于六轴规划组，
本例没有夹爪开合界面。Gazebo 默认自动播放；若手动暂停，执行前先点 Play。
终端 `Ctrl+C` 结束。重置 Gazebo 世界后应重启整套 launch，使时钟与控制器重新初始化。

无窗口模式：`ros2 launch dr_xcobo_gazebo gazebo.launch.py gui:=false rviz:=false`。
`gui:=false` 仅关闭 Gazebo 界面，物理服务器仍运行；`rviz:=false` 仅关闭 RViz，
MoveIt 仍运行。同一 ROS domain 内一次只运行一套本例。

**碰撞场景限制：** Gazebo 地面及后来添加的物体**不会自动进入 MoveIt 碰撞场景**，
规划成功不等于能避开这些物体。靠近障碍物前需在 MoveIt 中添加对应碰撞对象。
本例没有感知或场景同步桥接，保留原 CAD 碰撞网格，Gazebo 转换后的碰撞形状与
接触效果仍需实测。

**仿真参数：** 原模型速度/effort 的零值仅在派生副本中改成演示值：六轴 0.5 rad/s、
5 N·m，夹指 0.02 m/s、5 N；规划加速度分别为 1 rad/s² 与 0.04 m/s²，默认缩放 0.2。
位置反馈增益为 0.1，采用位置误差生成速度指令。这些均不是实际硬件额定值，
不是经验证的控制调参结果，也不是经过标定的电机力矩模型。原基座没有惯量，
本包新增明确标注的 1 kg 箱体占位惯量并固定到 world；其他九个 link 的惯量保留。
详细差异见 [MIGRATION.md](MIGRATION.md)，来源见 [NOTICE.md](NOTICE.md)。

检查时应看到三个控制器为 `active`，`/joint_states` 包含八个可动关节，播放时
`/clock` 持续变化。生成模型或控制器激活失败会停止后续启动，请先查看首条错误。
离线验证和运行诊断命令见上方 “Configuration and checks”。
