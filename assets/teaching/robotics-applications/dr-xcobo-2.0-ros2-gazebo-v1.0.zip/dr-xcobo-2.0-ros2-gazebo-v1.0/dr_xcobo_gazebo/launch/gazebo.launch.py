"""DR-xcobo Gazebo Harmonic simulation with MoveIt 2; no physical hardware."""

from pathlib import Path
import shlex

import xacro
import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument, EmitEvent, IncludeLaunchDescription, LogError,
    RegisterEventHandler,
)
from launch.conditions import IfCondition, UnlessCondition
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def _load_yaml(path):
    with path.open(encoding="utf-8") as stream:
        return yaml.safe_load(stream)


def _after_success(next_actions, operation):
    """Do not start dependent nodes after a failed spawn/controller activation."""
    def on_exit(event, _context):
        if event.returncode != 0:
            reason = f"Failed: {operation}. Inspect the preceding process output."
            return [LogError(msg=reason), EmitEvent(event=Shutdown(reason=reason))]
        return next_actions

    return on_exit


def generate_launch_description():
    package = Path(get_package_share_directory("dr_xcobo_gazebo"))
    config = package / "config"
    controller_file = str(config / "ros2_controllers.yaml")
    # Expand the installed absolute YAML path before Gazebo parses the URDF.
    robot_xml = xacro.process_file(
        str(package / "urdf" / "dr_xcobo.urdf.xacro"),
        mappings={"controllers_file": controller_file},
    ).toxml()
    description = {"robot_description": ParameterValue(robot_xml, value_type=str)}
    semantic = {
        "robot_description_semantic": ParameterValue(
            (config / "dr_xcobo.srdf").read_text(encoding="utf-8"), value_type=str
        )
    }
    kinematics = {"robot_description_kinematics": _load_yaml(config / "kinematics.yaml")}
    limits = {"robot_description_planning": _load_yaml(config / "joint_limits.yaml")}
    pipelines = {
        "planning_pipelines": ["ompl"],
        "default_planning_pipeline": "ompl",
        "ompl": _load_yaml(config / "ompl_planning.yaml"),
    }
    sim_time = {"use_sim_time": True}
    gz_launch = Path(get_package_share_directory("ros_gz_sim")) / "launch" / "gz_sim.launch.py"
    # The upstream launch passes gz_args through a shell. Quote the file path.
    world = shlex.quote(str(package / "worlds" / "dr_xcobo.sdf"))
    gui = LaunchConfiguration("gui")
    gazebo_gui = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(str(gz_launch)),
        condition=IfCondition(gui),
        launch_arguments={"gz_args": f"-r -v 2 {world}", "on_exit_shutdown": "true"}.items(),
    )
    gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(str(gz_launch)),
        condition=UnlessCondition(gui),
        launch_arguments={"gz_args": f"-r -s -v 2 {world}", "on_exit_shutdown": "true"}.items(),
    )
    clock_bridge = Node(
        package="ros_gz_bridge", executable="parameter_bridge", name="clock_bridge",
        output="screen",
        # '[' is strictly Gazebo -> ROS. Do not bridge /clock in both directions.
        arguments=["/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock"],
        parameters=[sim_time],
    )
    robot_state_publisher = Node(
        package="robot_state_publisher", executable="robot_state_publisher",
        name="robot_state_publisher", output="screen", parameters=[description, sim_time],
    )
    spawn_robot = Node(
        package="ros_gz_sim", executable="create", name="spawn_dr_xcobo", output="screen",
        arguments=["-world", "dr_xcobo_world", "-topic", "/robot_description",
                   "-name", "dr_xcobo", "-allow_renaming", "false"],
        parameters=[sim_time],
    )

    # Gazebo's gz_ros2_control plugin owns controller_manager; do not launch a
    # separate ros2_control_node. All three controllers receive their YAML file.
    def spawner(controller):
        return Node(
            package="controller_manager", executable="spawner",
            name=f"spawn_{controller}", output="screen", parameters=[sim_time],
            arguments=[controller, "--controller-manager", "/controller_manager",
                       "--param-file", controller_file,
                       "--controller-manager-timeout", "120", "--switch-timeout", "30"],
        )

    state_spawner = spawner("joint_state_broadcaster")
    finger_spawner = spawner("finger_hold_controller")
    arm_spawner = spawner("arm_controller")
    move_group = Node(
        package="moveit_ros_move_group", executable="move_group", name="move_group",
        output="screen",
        parameters=[description, semantic, kinematics, limits, pipelines,
                    _load_yaml(config / "moveit_controllers.yaml"), sim_time,
                    {"allow_trajectory_execution": True,
                     "publish_robot_description_semantic": True,
                     "publish_planning_scene": True,
                     "publish_geometry_updates": True,
                     "publish_state_updates": True,
                     "publish_transforms_updates": True,
                     "monitor_dynamics": False}],
    )
    rviz = Node(
        package="rviz2", executable="rviz2", name="rviz2", output="log",
        condition=IfCondition(LaunchConfiguration("rviz")),
        arguments=["-d", str(config / "moveit.rviz")],
        parameters=[description, semantic, kinematics, limits, pipelines, sim_time],
    )
    return LaunchDescription([
        DeclareLaunchArgument("gui", default_value="true", description="Start the Gazebo GUI"),
        DeclareLaunchArgument("rviz", default_value="true", description="Start RViz2"),
        RegisterEventHandler(OnProcessExit(
            target_action=spawn_robot,
            on_exit=_after_success([state_spawner], "spawn Gazebo model"))),
        RegisterEventHandler(OnProcessExit(
            target_action=state_spawner,
            on_exit=_after_success([finger_spawner], "activate joint_state_broadcaster"))),
        RegisterEventHandler(OnProcessExit(
            target_action=finger_spawner,
            on_exit=_after_success([arm_spawner], "activate finger_hold_controller"))),
        RegisterEventHandler(OnProcessExit(
            target_action=arm_spawner,
            on_exit=_after_success([move_group, rviz], "activate arm_controller"))),
        gazebo_gui, gazebo_server, clock_bridge, robot_state_publisher, spawn_robot,
    ])
