#!/usr/bin/env python3
"""Offline configuration checks. Does not import ROS, launch nodes or use devices."""

import argparse
import ast
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import xacro
import yaml


ARM = [f"Joint{index}" for index in range(1, 7)]
FINGERS = ["Joint_FingerR", "Joint_FingerL"]
MOVABLE = ARM + FINGERS
PACKAGE = "dr_xcobo_gazebo"


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def load_yaml(path):
    with path.open(encoding="utf-8") as stream:
        return yaml.safe_load(stream)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def xml_signature(element):
    """Compare XML meaning while ignoring formatting and attribute order."""
    return (
        element.tag,
        tuple(sorted(element.attrib.items())),
        (element.text or "").strip(),
        tuple(xml_signature(child) for child in element),
    )


def validate(root, source_root=None):
    manifest = ET.parse(root / "package.xml").getroot()
    require(manifest.findtext("name") == PACKAGE, "Wrong package name")
    require(manifest.findtext("export/build_type") == "ament_cmake", "Wrong build type")

    controller_file = str((root / "config/ros2_controllers.yaml").resolve())
    expanded = xacro.process_file(
        str(root / "urdf/dr_xcobo.urdf.xacro"),
        mappings={"controllers_file": controller_file},
    ).toxml()
    require("$(arg" not in expanded, "Unexpanded Xacro argument")
    robot = ET.fromstring(expanded)
    semantic = ET.parse(root / "config/dr_xcobo.srdf").getroot()
    require(robot.get("name") == semantic.get("name") == "Dr_arm_6_desk", "Robot names differ")
    links = {link.get("name") for link in robot.findall("link")}
    joints = {joint.get("name"): joint for joint in robot.findall("joint")}
    require(len(links) == 11 and len(joints) == 10, "Unexpected robot topology")
    require(set(name for name, joint in joints.items() if joint.get("type") != "fixed") == set(MOVABLE),
            "Expected six arm joints and two movable finger joints")
    for joint in joints.values():
        require(joint.find("parent").get("link") in links, "Unknown parent link")
        require(joint.find("child").get("link") in links, "Unknown child link")
    arm = semantic.find("group[@name='arm']")
    require(arm is not None, "Missing arm group")
    require({joint.get("name") for joint in arm.findall("joint")} == set(ARM), "Wrong arm group joints")
    require(arm.find("chain").attrib == {"base_link": "base_link", "tip_link": "Link6"}, "Wrong arm chain")

    mesh_files = list((root / "meshes").glob("*.STL"))
    require(len(mesh_files) == 10, "Expected ten meshes")
    provenance = json.loads((root / "config/source_provenance.json").read_text())
    for path in mesh_files:
        key = f"Dr_arm_6_desk/meshes/{path.name}"
        require(digest(path) == provenance["sha256"][key], f"Mesh changed: {path.name}")
    for mesh in robot.findall(".//mesh"):
        uri = mesh.get("filename")
        prefix = f"package://{PACKAGE}/"
        require(uri.startswith(prefix), f"Wrong mesh package URI: {uri}")
        require((root / uri[len(prefix):]).is_file(), f"Missing mesh: {uri}")
    require(digest(root / "config/dr_xcobo.srdf") ==
            provenance["sha256"]["Dr_arm_6_desk_moveit/config/Dr_arm_6_desk.srdf"],
            "Source SRDF changed")

    control = robot.find("ros2_control")
    require(control is not None and control.get("type") == "system", "Missing ros2_control system")
    require(control.findtext("hardware/plugin") == "gz_ros2_control/GazeboSimSystem", "Unexpected hardware plugin")
    control_joints = {joint.get("name"): joint for joint in control.findall("joint")}
    require(set(control_joints) == set(MOVABLE), "Missing control state for movable joints")
    for name, joint in control_joints.items():
        require([entry.get("name") for entry in joint.findall("command_interface")] == ["position"],
                f"Unexpected command interfaces: {name}")
        require({entry.get("name") for entry in joint.findall("state_interface")} == {"position", "velocity"},
                f"Missing state interfaces: {name}")
        initial = float(joint.find("state_interface[@name='position']/param[@name='initial_value']").text)
        require(initial == (0.02 if name in FINGERS else 0.0), f"Wrong initial state: {name}")
        limit = joints[name].find("limit")
        expected_bounds = (0.0, 0.04) if name in FINGERS else (-3.14, 3.14)
        require((float(limit.get("lower")), float(limit.get("upper"))) == expected_bounds,
                f"Position limits changed: {name}")
        require(float(limit.get("effort")) == 5.0, f"Unexpected demo effort: {name}")
        require(float(limit.get("velocity")) == (0.02 if name in FINGERS else 0.5),
                f"Unexpected demo velocity: {name}")

    configs = {path.name: load_yaml(path) for path in (root / "config").glob("*.yaml")}
    controllers = configs["ros2_controllers.yaml"]
    cm = controllers["controller_manager"]["ros__parameters"]
    require(cm["joint_state_broadcaster"]["type"] == "joint_state_broadcaster/JointStateBroadcaster", "Wrong broadcaster")
    require(cm["arm_controller"]["type"] == "joint_trajectory_controller/JointTrajectoryController", "Wrong controller")
    jtc = controllers["arm_controller"]["ros__parameters"]
    require(jtc["joints"] == ARM, "Trajectory controller must control only the arm")
    require(jtc["command_interfaces"] == ["position"], "Wrong trajectory command interface")
    require(jtc["state_interfaces"] == ["position", "velocity"], "Wrong trajectory state interfaces")
    broadcaster = controllers["joint_state_broadcaster"]["ros__parameters"]
    require(broadcaster["joints"] == MOVABLE, "Broadcaster must publish all eight movable joints")
    require(broadcaster["use_local_topics"] is False, "Expected global /joint_states")
    moveit = configs["moveit_controllers.yaml"]
    require(moveit["moveit_manage_controllers"] is False, "Controllers are activated by the launch file")
    simple = moveit["moveit_simple_controller_manager"]
    require(simple["controller_names"] == ["arm_controller"], "Wrong MoveIt controller list")
    require(simple["arm_controller"]["joints"] == ARM, "MoveIt/controller joints differ")
    require(simple["arm_controller"]["action_ns"] == "follow_joint_trajectory", "Wrong action namespace")
    require(simple["arm_controller"]["type"] == "FollowJointTrajectory", "Wrong controller action type")

    limits = configs["joint_limits.yaml"]["joint_limits"]
    require(set(limits) == set(MOVABLE), "Missing joint limit configuration")
    for name, entry in limits.items():
        require(entry["has_velocity_limits"] and entry["has_acceleration_limits"], "Expected finite demo limits")
        require(entry["max_velocity"] == float(joints[name].find("limit").get("velocity")),
                f"URDF/MoveIt velocity mismatch: {name}")
        require(entry["max_acceleration"] == (0.04 if name in FINGERS else 1.0), "Wrong demo acceleration")
    ompl = configs["ompl_planning.yaml"]
    require(ompl["planning_plugins"] == ["ompl_interface/OMPLPlanner"], "Wrong Jazzy planning plugin schema")
    require(isinstance(ompl["request_adapters"], list) and isinstance(ompl["response_adapters"], list),
            "Jazzy adapters must be lists")
    require("default_planning_response_adapters/AddTimeOptimalParameterization" in ompl["response_adapters"],
            "Missing trajectory time parameterization")
    require(ompl["arm"]["default_planner_config"] in ompl["planner_configs"], "Unknown default planner")
    require(configs["kinematics.yaml"]["arm"]["kinematics_solver"] == "kdl_kinematics_plugin/KDLKinematicsPlugin",
            "Wrong kinematics plugin")

    rviz = load_yaml(root / "config/moveit.rviz")["Visualization Manager"]
    require(rviz["Global Options"]["Fixed Frame"] == "world", "Wrong RViz fixed frame")
    motion = next(display for display in rviz["Displays"] if display["Class"] == "moveit_rviz_plugin/MotionPlanning")
    require(motion["Planning Request"]["Planning Group"] == "arm", "Wrong RViz group")
    launch_source = (root / "launch/gazebo.launch.py").read_text()
    tree = ast.parse(launch_source)
    require("--param-file" in launch_source, "Jazzy spawners need controller parameters")
    require("event.returncode != 0" in launch_source, "Spawner failure must block startup")
    require('LaunchConfiguration("rviz")' in launch_source, "Missing headless launch argument")
    require('"use_sim_time": True' in launch_source, "Gazebo requires simulation time")
    require(not any(isinstance(node, (ast.Import, ast.ImportFrom)) and
                    any(alias.name in ("serial", "rospy") for alias in node.names)
                    for node in ast.walk(tree)), "Hardware/ROS 1 import found")

    validate_gazebo(root, robot, controllers, manifest, launch_source, tree, controller_file)

    if source_root:
        for relative, expected in provenance["sha256"].items():
            require(digest(source_root / relative) == expected, f"Source hash mismatch: {relative}")
        original = ET.parse(source_root / "Dr_arm_6_desk/urdf/Dr_arm_6_desk.urdf").getroot()
        robot.remove(control)
        robot.remove(robot.find("link[@name='world']"))
        robot.remove(robot.find("joint[@name='world_to_base']"))
        base = robot.find("link[@name='base_link']")
        base.remove(base.find("inertial"))
        for extension in list(robot.findall("gazebo")):
            robot.remove(extension)
        for mesh in robot.findall(".//mesh"):
            mesh.set("filename", mesh.get("filename").replace(f"package://{PACKAGE}/", "package://Dr_arm_6_desk/"))
        original_joints = {joint.get("name"): joint for joint in original.findall("joint")}
        for joint in robot.findall("joint"):
            if joint.get("type") != "fixed":
                for key in ("effort", "velocity"):
                    joint.find("limit").set(key, original_joints[joint.get("name")].find("limit").get(key))
        require(xml_signature(robot) == xml_signature(original), "Undocumented model/geometry changes")

    return {"static_checks": "passed", "meshes_byte_identical": 10,
            "arm_joints": 6, "published_movable_joints": 8,
            "source_model_compared": source_root is not None,
            "gazebo_runtime_tested": False, "ros2_runtime_tested": False,
            "source_link_inertias_preserved": 9 if source_root else "not compared",
            "finger_hold_controller": "position_controllers/JointGroupPositionController"}


def validate_gazebo(root, robot, controllers, manifest, launch_source, tree, controller_file):
    fixed = robot.find("joint[@name='world_to_base']")
    require(fixed is not None and fixed.get("type") == "fixed", "Base must be world-fixed")
    require(fixed.find("parent").get("link") == "world" and
            fixed.find("child").get("link") == "base_link", "Wrong world attachment")
    require(fixed.find("origin").attrib == {"xyz": "0 0 0", "rpy": "0 0 0"}, "World offset changed")
    for link in robot.findall("link"):
        if link.get("name") == "world":
            continue
        inertial = link.find("inertial")
        require(inertial is not None, f"Missing inertia: {link.get('name')}")
        require(float(inertial.find("mass").get("value")) > 0, "Nonpositive mass")
        inertia = {key: float(value) for key, value in inertial.find("inertia").attrib.items()}
        a, b, c = inertia["ixx"], inertia["iyy"], inertia["izz"]
        d, e, f = inertia["ixy"], inertia["ixz"], inertia["iyz"]
        require(a > 0 and a*b-d*d > 0 and
                a*b*c+2*d*e*f-a*f*f-b*e*e-c*d*d > 0, "Inertia is not positive definite")
    require(robot.find("gazebo[@reference='Joint_Cam']/preserveFixedJoint").text == "true",
            "Camera fixed joint must be preserved")
    plugin = robot.find("gazebo/plugin")
    require(plugin is not None and plugin.get("name") == "gz_ros2_control::GazeboSimROS2ControlPlugin",
            "Wrong Gazebo system plugin")
    require(plugin.get("filename") == "gz_ros2_control-system", "Wrong plugin library")
    require(plugin.findtext("parameters") == controller_file, "Controller YAML path was not expanded")
    require(plugin.findtext("hold_joints") == "true", "Missing pre-activation holding")
    require(float(plugin.findtext("position_proportional_gain")) == 0.1, "Unexpected servo gain")
    require(not robot.findall("gazebo/static"), "Do not make the articulated robot static")
    require(manifest.find("export/gazebo_ros").get("gazebo_model_path") == "${prefix}/../",
            "Missing Gazebo package resource export")
    deps = {element.text for element in manifest.findall("exec_depend")}
    require({"ros_gz_sim", "ros_gz_bridge", "gz_ros2_control", "xacro", "position_controllers"} <= deps,
            "Missing Gazebo runtime dependency")
    for name in ("controller_manager", "joint_state_broadcaster", "finger_hold_controller", "arm_controller"):
        require(controllers[name]["ros__parameters"]["use_sim_time"] is True, f"Wall-clock controller: {name}")
    cm = controllers["controller_manager"]["ros__parameters"]
    require(cm["update_rate"] == 100, "Unexpected control rate")
    require(cm["finger_hold_controller"]["type"] == "position_controllers/JointGroupPositionController",
            "Wrong finger controller plugin")
    require(controllers["finger_hold_controller"]["ros__parameters"]["joints"] == FINGERS,
            "Finger holding must claim both finger joints")

    world = ET.parse(root / "worlds/dr_xcobo.sdf").getroot().find("world")
    require(world.get("name") == "dr_xcobo_world", "World/spawn names differ")
    require(world.findtext("gravity") == "0 0 -9.81", "Unexpected gravity")
    require(float(world.findtext("physics/max_step_size")) == 0.001, "Unexpected physics step")
    require(world.findtext("model[@name='ground_plane']/static") == "true", "Ground must be static")
    require(world.find("light[@type='directional']") is not None, "Missing light")
    systems = {plugin.get("name") for plugin in world.findall("plugin")}
    require({"gz::sim::systems::Physics", "gz::sim::systems::UserCommands",
             "gz::sim::systems::SceneBroadcaster"} <= systems, "Missing Gazebo world system")
    require('LaunchConfiguration("gui")' in launch_source, "Missing server-only option")
    require('"/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock"' in launch_source,
            "Clock must be bridged strictly Gazebo to ROS")
    require('"/clock@rosgraph_msgs/msg/Clock@' not in launch_source, "Bidirectional clock bridge")
    require('"-r -s -v 2 ' in launch_source, "Headless server must start playing")
    require('"use_sim_time": False' not in launch_source, "Mixed ROS clocks")
    require('executable="ros2_control_node"' not in launch_source, "Duplicate controller manager")
    require('"-topic", "/robot_description"' in launch_source, "Spawn must use published description")
    require('mappings={"controllers_file": controller_file}' in launch_source, "Missing Xacro mapping")
    handlers = [node for node in ast.walk(tree)
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                and node.func.id == "OnProcessExit"]
    gates = {}
    for handler in handlers:
        keywords = {item.arg: item.value for item in handler.keywords}
        callback = keywords["on_exit"]
        require(isinstance(callback, ast.Call) and isinstance(callback.func, ast.Name)
                and callback.func.id == "_after_success", "Every startup step needs a success gate")
        gates[keywords["target_action"].id] = [node.id for node in callback.args[0].elts]
    require(gates == {"spawn_robot": ["state_spawner"], "state_spawner": ["finger_spawner"],
                      "finger_spawner": ["arm_spawner"], "arm_spawner": ["move_group", "rviz"]},
            "Startup sequencing changed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--source-root", type=Path, help="Optional directory containing the two original ROS 1 packages")
    args = parser.parse_args()
    print(json.dumps(validate(args.package_root, args.source_root), indent=2))


if __name__ == "__main__":
    main()
