# ROS 1 → ROS 2 migration record

Source packages: `Dr_arm_6_desk` and `Dr_arm_6_desk_moveit`.
Target: `dr_xcobo_moveit_config`, ROS 2 Jazzy / Ubuntu 24.04.
The source packages were not edited.

## Preserved model

- All **10 STL files are byte-identical** to the supplied source meshes.
- Robot name `Dr_arm_6_desk`, all 10 link names, all 9 joint names, joint types,
  parent/child relationships, axes, origins, position limits, inertial data,
  visual and collision geometry, materials and colors are preserved.
- The SRDF is copied unchanged: planning group `arm`, base `base_link`, tip `Link6`,
  and the original disabled-collision pairs. Collision exemptions are inherited
  configuration, not newly validated collision guarantees.
- Model references now use `package://dr_xcobo_moveit_config/meshes/...` so the
  example is self-contained and does not require the original ROS 1 packages.

`config/source_provenance.json` records the original mesh/model/config hashes.
The optional source-comparison check verifies geometry and limits after excluding
only the explicitly documented derived-model additions below.

## Derived-model changes

The original URDF gives every movable joint zero velocity and zero effort.
The ROS 2 copy supplies **demonstration values, not physical hardware ratings**:

| Joints | URDF velocity | URDF effort | MoveIt acceleration |
|---|---:|---:|---:|
| `Joint1`–`Joint6` | 0.5 rad/s | 5.0 N·m | 1.0 rad/s² |
| `Joint_FingerR`, `Joint_FingerL` | 0.02 m/s | 5.0 N | 0.04 m/s² |

Original position bounds remain `[-3.14, 3.14]` rad for the arm and `[0, 0.04]` m
for the fingers. MoveIt default velocity/acceleration scaling is 0.2; RViz may
apply its own displayed scaling settings.

An additional `<ros2_control>` block names only `mock_components/GenericSystem`.
The six arm positions start at zero; both fingers start at 0.02 m. All eight
movable joints expose position commands and position/velocity state interfaces.
Only `Joint1`–`Joint6` are claimed by `arm_controller`; unclaimed finger commands
leave the initial positions unchanged. `joint_state_broadcaster` publishes all
eight joints, so the finger links have complete transforms.

`calculate_dynamics=true` derives velocity feedback from position changes; this
is finite-difference mock feedback, **not** a physics, inertia, gravity, contact,
load, or actuator simulation. The effort numbers are unused by the position
controller. There is no gripper control group.

## ROS infrastructure changes

- One lowercase `ament_cmake` package replaces the two ROS 1 catkin packages.
- Python launch uses installed package paths, with no machine-specific absolute paths.
- `robot_state_publisher` publishes the description; the Jazzy controller manager
  consumes `/robot_description`.
- Each controller spawner receives `--param-file`, as required by Jazzy's controller
  parameter handling. The broadcaster activates first, then the six-axis trajectory
  controller. MoveIt/RViz start only after successful activation; failure shuts down.
- OMPL uses Jazzy's list-valued `planning_plugins`, `request_adapters`, and
  `response_adapters`, with RRTConnect and time parameterization. KDL is retained;
  its timeout is 0.05 s in this example (the source used 0.005 s).
- MoveIt uses the simple controller manager and
  `/arm_controller/follow_joint_trajectory`. Controllers are already active, so
  MoveIt controller switching is disabled.
- RViz2 uses the correct `arm` group, `base_link` frame, and ROS 2 topics.
- `use_sim_time=false`; no `/clock`, sensor feed, warehouse database, Gazebo, or
  hardware bridge is launched. `rviz:=false` only suppresses the GUI.
- The ROS 1 Python serial drivers and automatic motion scripts are not included.

## Verification boundary

Preparation includes XML/YAML/Python syntax checks, cross-file controller and
joint consistency, mesh hashes, source-model comparison, and launch structure
checks. It does **not** include a ROS 2 build, launch, planning, controller execution,
or physical robot test. Docker, ROS 2, and colcon were unavailable on the preparation host.

On a Jazzy machine, complete the README's build and headless checks, then verify
RViz Plan and Execute on several reachable, collision-free targets. Watch for
controller errors and confirm the displayed robot follows the completed trajectory.
Those runtime checks remain necessary before describing the package as runtime-tested.

## 中文说明

原 ROS 1 包未修改。10 个 STL 保持字节一致；机器人、link、joint 名称，以及关节类型、
轴、原点、父子关系、位置限位、惯性和可视/碰撞几何均保留。SRDF 原样复制，仍使用
`arm` 规划组和原碰撞豁免表；这些豁免未重新做物理碰撞验证。

ROS 2 副本只改 mesh 包路径、补充模拟用的速度/effort 数值，并加入固定的 GenericSystem
模拟控制块。加速度和缩放值在 MoveIt 配置中给出。表中的数值全部是演示值，不是实物
额定参数。六轴可规划并执行，两个夹指仅保持 0.02 m 初值、发布状态。

本包采用 Jazzy 的 ROS 2 控制器参数、OMPL 插件和 RViz2 配置。先激活状态广播器和六轴
控制器，再启动 MoveIt/RViz。没有真机串口脚本、Gazebo 或动力学仿真。

当前只完成静态检查，尚未进行 ROS 2 构建、运行或 Plan & Execute 测试。
