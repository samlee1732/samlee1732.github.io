# Source attribution

The robot description, SRDF and STL assets come from the supplied
`Dr_arm_6_desk` and `Dr_arm_6_desk_moveit` ROS 1 packages. Their manifests declare
the license as `BSD`; that declaration is retained in this derived package.
The MoveIt source manifest identifies its author as `Dr_Robot`.

The original SolidWorks-to-URDF exporter attribution remains in the URDF header.
New ROS 2 configuration and documentation describe the adaptation explicitly;
they do not change the source model's attribution.
