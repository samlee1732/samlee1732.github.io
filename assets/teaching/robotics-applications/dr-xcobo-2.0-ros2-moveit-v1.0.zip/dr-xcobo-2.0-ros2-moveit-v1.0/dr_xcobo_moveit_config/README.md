# DR-xcobo 2.0 — ROS 2 / MoveIt 2

## English

This self-contained example targets **Ubuntu 24.04 + ROS 2 Jazzy + MoveIt 2**.
It uses the original arm model and ten STL files, with `mock_components/GenericSystem`
for RViz2 **Plan and Execute**. It does not contain a physical robot driver,
serial connection, Gazebo world, or physics simulation. Only the six arm joints
are commanded; both finger joints stay at their initial position of **0.02 m**.

The package has been checked statically. **It has not been built or run in a ROS 2
environment during preparation.** See [MIGRATION.md](MIGRATION.md) for exact model
changes and the remaining runtime checks.

### 1. Install dependencies once

Start with ROS 2 Jazzy Desktop already installed and use a Bash terminal.
If `/opt/ros/jazzy/setup.bash` is missing, install ROS 2 Jazzy first.

```bash
source /opt/ros/jazzy/setup.bash
sudo apt update
sudo apt install build-essential unzip python3-colcon-common-extensions \
  python3-yaml ros-jazzy-ament-cmake ros-jazzy-ament-cmake-test \
  ros-jazzy-moveit ros-jazzy-ros2-control ros-jazzy-ros2-controllers \
  ros-jazzy-rviz2 ros-jazzy-robot-state-publisher
```

### 2. Extract and build once

Keep the downloaded ZIP in `~/Downloads/`. The outer archive directory may remain
inside `src`; colcon discovers the `dr_xcobo_moveit_config` package below it.

```bash
mkdir -p ~/dr_xcobo_moveit_ws/src
unzip ~/Downloads/dr-xcobo-2.0-ros2-moveit-v1.0.zip \
  -d ~/dr_xcobo_moveit_ws/src
cd ~/dr_xcobo_moveit_ws
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install --packages-select dr_xcobo_moveit_config
```

### 3. Launch in each new terminal

```bash
source /opt/ros/jazzy/setup.bash
source ~/dr_xcobo_moveit_ws/install/setup.bash
ros2 launch dr_xcobo_moveit_config demo.launch.py
```

The launcher waits for `joint_state_broadcaster`, then `arm_controller`, to become
active before starting MoveIt and RViz2. A controller startup failure stops the
launch instead of opening a partially initialized demo. No `roscore` is needed.
Use only one instance of this demo in the same ROS domain.

### 4. Plan and execute in RViz2

1. Check **Fixed Frame = `base_link`** and **Planning Group = `arm`**.
2. Set **Start State = current**. Enable **Query Goal State**, then drag the target
   using **Interact**, or adjust the target in **Joints**. Choose a reachable,
   collision-free goal.
3. Click **Plan** and inspect the displayed path.
4. Click **Execute** after a successful plan. The mock controller moves the
   displayed robot and publishes joint feedback. **Plan & Execute** is also
   available. There is no gripper planning group or gripper controller.
5. Press **Ctrl+C** in the launch terminal to stop.

The initial arm angles are zero. A goal near a collision or joint bound can fail;
choose another goal rather than disabling collision checks. Simulation limits
are illustrative: arm velocity **0.5 rad/s**, acceleration **1.0 rad/s²**, and URDF
effort **5 N·m**. Finger limits are **0.02 m/s**, **0.04 m/s²**, and **5 N**.
These are **not hardware ratings**. The original position limits are unchanged.

### Headless launch and checks

```bash
ros2 launch dr_xcobo_moveit_config demo.launch.py rviz:=false
```

In a second terminal, source the same two setup files, then run:

```bash
ros2 control list_controllers
ros2 topic echo /joint_states --once
ros2 action list
```

Expected: both controllers are `active`; joint states include `Joint1`–`Joint6`,
`Joint_FingerR`, and `Joint_FingerL`; the action list includes
`/arm_controller/follow_joint_trajectory`. These are checks to perform on your
Jazzy system, not results obtained during preparation.

If the package is not found, check the build succeeded and source `install/setup.bash`.
If a spawner fails, read its first error and verify the ros2_control dependencies.
If RViz is blank, check `base_link`, `arm`, mesh installation, and `/joint_states`.
Source ROS 2 Jazzy only; do not mix a ROS 1 or another ROS 2 distribution in this shell.

Optional static tests after building:

```bash
cd ~/dr_xcobo_moveit_ws
colcon test --packages-select dr_xcobo_moveit_config
colcon test-result --verbose
```

## 中文

本包面向 **Ubuntu 24.04 + ROS 2 Jazzy + MoveIt 2**，使用同一机械臂模型和原始
10 个 STL。RViz2 中的规划与执行由 `mock_components/GenericSystem` 模拟。
包内没有真机驱动、串口连接、Gazebo 场景或物理动力学仿真。控制器只驱动六个机械臂
关节；两个夹指保持 **0.02 m** 初始位置，仅显示状态，没有夹爪规划组和控制器。

目前已完成静态核对，**制作时尚未在 ROS 2 环境中构建或运行**。迁移差异及待验证项
见 [MIGRATION.md](MIGRATION.md)。

### 首次使用

1. 先安装 ROS 2 Jazzy Desktop，使用 Bash，按英文第 1 节命令安装依赖。
2. 将 ZIP 保留原文件名放在 `~/Downloads/`，按第 2 节命令解压到
   `~/dr_xcobo_moveit_ws/src/`，再执行 `colcon build`。保留内部包名
   `dr_xcobo_moveit_config`；无需加入原 ROS 1 包。
3. 每个新终端都依次加载 `/opt/ros/jazzy/setup.bash` 与工作区的
   `install/setup.bash`，再运行：

```bash
ros2 launch dr_xcobo_moveit_config demo.launch.py
```

启动时先激活关节状态广播器，再激活机械臂轨迹控制器，成功后才打开 MoveIt 与 RViz2。
控制器启动失败会停止本次启动。无需 `roscore`，同一 ROS 域内只运行一个本演示实例。

### RViz2 操作

1. 确认 **Fixed Frame = `base_link`**，**Planning Group = `arm`**。
2. 起点选择 **current**；启用 **Query Goal State**，用 **Interact** 拖动目标位姿，
   或在 **Joints** 页调整目标关节。目标应可达且无碰撞。
3. 点击 **Plan** 查看规划路径；成功后点击 **Execute**，也可使用 **Plan & Execute**。
   此处只改变模拟关节和显示模型，不驱动实物。
4. 在启动终端按 **Ctrl+C** 结束。

六轴初始角度为零。规划失败时先检查起点、目标、碰撞与关节范围。ROS 2 派生模型仅为
演示填入正的速度、加速度和 effort：六轴分别为 **0.5 rad/s、1.0 rad/s²、5 N·m**；
夹指为 **0.02 m/s、0.04 m/s²、5 N**。这些数值**不是硬件额定值**，原位置限位不变。

不打开 GUI 时使用 `rviz:=false`；另开已加载环境的终端，运行英文“Headless”中的
三条检查命令。预期两个控制器为 `active`，`/joint_states` 包含六轴及两个夹指，
存在 `/arm_controller/follow_joint_trajectory`。这些是用户端待执行的检查项，
不是已完成的实跑验证。

找不到包时，检查构建结果和工作区 `source`；控制器报错时查看首条 spawner 错误和依赖；
模型不显示时检查 `base_link`、`arm`、网格文件和关节状态。不要在同一终端混用 ROS 1
或其他 ROS 2 版本。

## Official references / 官方资料

- [ROS 2 Jazzy Ubuntu installation](https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html)
- [Jazzy ros2_control migration notes](https://control.ros.org/jazzy/doc/ros2_control/doc/migration.html)
- [GenericSystem mock hardware](https://control.ros.org/jazzy/doc/ros2_control/hardware_interface/doc/mock_components_userdoc.html)
- [Joint trajectory controller](https://control.ros.org/jazzy/doc/ros2_controllers/joint_trajectory_controller/doc/userdoc.html)
- [MoveIt Jazzy OMPL configuration](https://github.com/moveit/moveit2/blob/jazzy/moveit_configs_utils/default_configs/ompl_planning.yaml)
