"""MoveIt 2 + ros2_control mock execution; no physical hardware interface."""

from pathlib import Path

import yaml
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, LogError, RegisterEventHandler
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def _load_yaml(path):
    with path.open(encoding="utf-8") as stream:
        return yaml.safe_load(stream)


def _after_success(next_actions, controller_name):
    """Continue only after the spawner has activated its controller successfully."""
    def on_exit(event, _context):
        if event.returncode != 0:
            reason = f"Failed to activate {controller_name}; inspect the spawner output."
            return [LogError(msg=reason), EmitEvent(event=Shutdown(reason=reason))]
        return next_actions

    return on_exit


def generate_launch_description():
    package = Path(get_package_share_directory("dr_xcobo_moveit_config"))
    config = package / "config"
    description = {
        "robot_description": ParameterValue(
            (package / "urdf" / "dr_xcobo.urdf").read_text(encoding="utf-8"),
            value_type=str,
        )
    }
    semantic = {
        "robot_description_semantic": ParameterValue(
            (config / "dr_xcobo.srdf").read_text(encoding="utf-8"), value_type=str
        )
    }
    kinematics = {"robot_description_kinematics": _load_yaml(config / "kinematics.yaml")}
    limits = {"robot_description_planning": _load_yaml(config / "joint_limits.yaml")}
    pipelines = {
        "planning_pipelines": ["ompl"],
        "default_planning_pipeline": "ompl",
        "ompl": _load_yaml(config / "ompl_planning.yaml"),
    }
    controller_file = str(config / "ros2_controllers.yaml")

    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        name="robot_state_publisher",
        output="screen",
        parameters=[description, {"use_sim_time": False}],
    )
    controller_manager = Node(
        package="controller_manager",
        executable="ros2_control_node",
        name="controller_manager",
        output="screen",
        parameters=[controller_file, {"use_sim_time": False}],
        # Jazzy receives the URDF on this topic, published by robot_state_publisher.
        remappings=[("robot_description", "/robot_description")],
    )

    def spawner(controller):
        return Node(
            package="controller_manager",
            executable="spawner",
            name=f"spawn_{controller}",
            output="screen",
            arguments=[
                controller,
                "--controller-manager", "/controller_manager",
                # Jazzy controllers need their own parameter file, not only the
                # file supplied to ros2_control_node.
                "--param-file", controller_file,
                "--controller-manager-timeout", "60",
                "--switch-timeout", "20",
            ],
        )

    state_spawner = spawner("joint_state_broadcaster")
    arm_spawner = spawner("arm_controller")
    move_group = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        name="move_group",
        output="screen",
        parameters=[
            description,
            semantic,
            kinematics,
            limits,
            pipelines,
            _load_yaml(config / "moveit_controllers.yaml"),
            {
                "allow_trajectory_execution": True,
                "publish_robot_description_semantic": True,
                "publish_planning_scene": True,
                "publish_geometry_updates": True,
                "publish_state_updates": True,
                "publish_transforms_updates": True,
                "monitor_dynamics": False,
                "use_sim_time": False,
            },
        ],
    )
    rviz = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="log",
        condition=IfCondition(LaunchConfiguration("rviz")),
        arguments=["-d", str(config / "moveit.rviz")],
        parameters=[description, semantic, kinematics, limits, pipelines, {"use_sim_time": False}],
    )

    # Register handlers before starting either spawner. Each spawner waits for
    # controller_manager; move_group/RViz start only after both are active.
    return LaunchDescription([
        DeclareLaunchArgument("rviz", default_value="true", description="Start RViz2"),
        RegisterEventHandler(OnProcessExit(
            target_action=state_spawner,
            on_exit=_after_success([arm_spawner], "joint_state_broadcaster"),
        )),
        RegisterEventHandler(OnProcessExit(
            target_action=arm_spawner,
            on_exit=_after_success([move_group, rviz], "arm_controller"),
        )),
        robot_state_publisher,
        controller_manager,
        state_spawner,
    ])
