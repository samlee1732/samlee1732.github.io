# DR-xcobo 2.0 - ROS 2 URDF Visualization

Robotics and Applications | SenseDex Lab | Package version 1.0.0

This teaching package displays the supplied DR-xcobo 2.0 model in RViz2 and
provides joint sliders. Its target environment is **Ubuntu 24.04 LTS Desktop
(Noble) with ROS 2 Jazzy Jalisco**. Static file checks have been completed, but
the package has **not been built or run in ROS 2 / RViz2** during preparation.

The model has 10 links and 9 joints: 6 revolute, 2 prismatic, and 1 fixed. All
10 STL meshes are included. Keep the complete package: the URDF references the
meshes through `package://dr_xcobo_description/meshes/...`.

## Package contents

```text
dr_xcobo_description/
  package.xml
  CMakeLists.txt
  README.md
  urdf/dr_xcobo_2.0.urdf
  meshes/                  # All 10 original STL files
  launch/display.launch.py
  rviz/urdf.rviz
```

## 1. Prepare the environment

Start with ROS 2 Jazzy and its apt repository already installed and configured
on Ubuntu 24.04. Use an Ubuntu Bash terminal. The commands below install this
package's build and visualization dependencies; they do not install a complete
ROS distribution. Do not source a ROS 1 environment in the same terminal.

```bash
source /opt/ros/jazzy/setup.bash
sudo apt update
sudo apt install build-essential unzip python3-colcon-common-extensions \
  ros-jazzy-ament-cmake ros-jazzy-ament-index-python \
  ros-jazzy-launch-ros ros-jazzy-ros2launch \
  ros-jazzy-robot-state-publisher ros-jazzy-joint-state-publisher \
  ros-jazzy-joint-state-publisher-gui ros-jazzy-rviz2
```

If `/opt/ros/jazzy/setup.bash` is missing, install or obtain the course's Jazzy
environment before continuing. RViz2 and the sliders require a graphical desktop.

## 2. Extract and build

Create a workspace source directory:

```bash
mkdir -p ~/ros2_ws/src
```

Extract the complete `dr_xcobo_description` directory from the downloaded ZIP
into `~/ros2_ws/src/`. The manifest should be located at
`~/ros2_ws/src/dr_xcobo_description/package.xml`. Do not add another directory
between the package and `src`, or copy only the `.urdf` file.

Then build from the workspace root:

```bash
cd ~/ros2_ws
colcon build --symlink-install --packages-select dr_xcobo_description
source install/setup.bash
```

This is an `ament_cmake` package. Do not use the ROS 1 `catkin_make` or
`roslaunch` commands with it.

## 3. Launch and explore

In a new Bash terminal, load both environments and start the model:

```bash
source /opt/ros/jazzy/setup.bash
source ~/ros2_ws/install/setup.bash
ros2 launch dr_xcobo_description display.launch.py
```

RViz2 and the separate Joint State Publisher GUI should open. Use the sliders
to inspect joint directions and ranges. The two fingers are independently
controlled because the supplied URDF has no mimic relationship between them.
Use RViz2's Move Camera tool to orbit, pan, and zoom. Press Ctrl+C in the launch
terminal to stop all nodes.

To display a static pose in RViz2 without the slider window, stop the previous
launch and run:

```bash
ros2 launch dr_xcobo_description display.launch.py gui:=false
```

To run both state publishers without either graphical window:

```bash
ros2 launch dr_xcobo_description display.launch.py gui:=false rviz:=false
```

The `gui` and `rviz` arguments independently accept `true` or `false`; both
default to `true`. Setting only `rviz:=false` still opens the slider window.
Run one display launch at a time. A ROS 1 master (`roscore`) is not required.

The launch file reads the installed URDF and passes it as a string parameter to
`robot_state_publisher`. That node publishes `/robot_description`, `/tf`, and
`/tf_static`. The selected joint-state publisher receives the model on
`/robot_description` and publishes `/joint_states`. RViz2's RobotModel display
uses `/robot_description` with **Transient Local** durability, **Reliable**
reliability, **Keep Last** history, and depth **1**. Its fixed frame is `base_link`.

## Troubleshooting

- **Package not found:** check the manifest path above, rebuild, and source
  `~/ros2_ws/install/setup.bash` in the current terminal.
- **Meshes missing:** keep all 10 STL files in `meshes/`, preserve the package
  name, and source the workspace before launching.
- **RobotModel empty:** check the launch terminal for node errors. In RViz2,
  set Description Source to `Topic`, Description Topic to `/robot_description`,
  and its Durability Policy to `Transient Local`. Keep Reliability Policy set
  to `Reliable`.
- **Fixed frame error:** set Global Options > Fixed Frame to `base_link` and
  check that the state publishers are running.
- **No sliders:** install `ros-jazzy-joint-state-publisher-gui` and start the
  default launch. `gui:=false` intentionally suppresses this window.
- **No graphical display:** use `gui:=false rviz:=false` for headless work.
  A working Ubuntu graphics session is needed to inspect the model visually.

## Model scope and verification

- The 10 meshes are byte-for-byte copies of the supplied model assets.
- The URDF filename and mesh package references were changed for this ROS 2
  package. All other URDF bytes are preserved, including the exporter attribution,
  robot name, geometry, inertial data, links, joints, and limits.
- All 8 movable joints retain the source values `effort="0"` and `velocity="0"`.
  They support this pose-visualization workflow; physical/controller limits must
  be reviewed separately before any planning, controller, or dynamics workflow.
- Static validation covers Python syntax, manifest and URDF parsing, the connected
  link/joint tree, RViz YAML and topic QoS, launch resource paths, and mesh hashes.
  It does not establish ROS 2 build success, DDS communication, or RViz2 rendering.
- This package contains no Gazebo integration, MoveIt configuration, controllers,
  or hardware-control drivers. Joint sliders change a displayed pose; they do
  not provide motion planning or a physics simulation.

## Source and license attribution

Converted from the supplied `Dr_arm_6_desk` model package for this course.
Sen Li maintains this teaching bundle; original model authorship is unspecified
in the supplied package manifest. The original SolidWorks exporter attribution
comment remains in the URDF.

The source manifest declares `BSD`. That label is retained in `package.xml`.
The supplied files did not include a standalone license text or a model copyright
holder. This conversion does not assert new ownership of the model or invent a
copyright notice.

## Official references

- [ROS 2 Jazzy on Ubuntu](https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html)
- [Jazzy robot_state_publisher interface](https://github.com/ros/robot_state_publisher/blob/jazzy/README.md)
- [Joint State Publisher ROS 2 source](https://github.com/ros/joint_state_publisher/tree/ros2)
- [Jazzy launch_ros Node API](https://github.com/ros2/launch_ros/blob/jazzy/launch_ros/launch_ros/actions/node.py)
- [Jazzy RViz2 RobotModel source](https://github.com/ros2/rviz/blob/jazzy/rviz_default_plugins/src/rviz_default_plugins/displays/robot_model/robot_model_display.cpp)

Course page: https://www.sensedex.online/teaching/robotics-applications/
