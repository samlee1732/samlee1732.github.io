"""Display the DR-xcobo 2.0 model with optional joint sliders and RViz2."""

from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    package_share = Path(get_package_share_directory('dr_xcobo_description'))
    urdf_path = package_share / 'urdf' / 'dr_xcobo_2.0.urdf'
    rviz_path = package_share / 'rviz' / 'urdf.rviz'
    robot_description = ParameterValue(
        urdf_path.read_text(encoding='utf-8'), value_type=str)
    gui = LaunchConfiguration('gui')
    rviz = LaunchConfiguration('rviz')

    return LaunchDescription([
        DeclareLaunchArgument(
            'gui', default_value='true', choices=['true', 'false'],
            description='Open the joint sliders; otherwise publish a static pose.'),
        DeclareLaunchArgument(
            'rviz', default_value='true', choices=['true', 'false'],
            description='Open RViz2 with the packaged robot display configuration.'),
        Node(
            package='robot_state_publisher', executable='robot_state_publisher',
            name='robot_state_publisher', output='screen',
            parameters=[{'robot_description': robot_description}]),
        # Both joint-state publishers receive the model on /robot_description.
        # The conditions ensure that only one publishes joint states at a time.
        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            name='joint_state_publisher', output='screen',
            condition=IfCondition(gui)),
        Node(
            package='joint_state_publisher', executable='joint_state_publisher',
            name='joint_state_publisher', output='screen',
            condition=UnlessCondition(gui)),
        Node(
            package='rviz2', executable='rviz2', name='rviz2', output='screen',
            arguments=['-d', str(rviz_path)], condition=IfCondition(rviz)),
    ])
