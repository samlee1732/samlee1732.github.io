# DR-xcobo 2.0 — URDF Robot Model

Teaching bundle v1.0 · Robotics and Applications · SenseDex Lab

This bundle contains the supplied `Dr_arm_6_desk` URDF and all 10 referenced STL
meshes, plus a ROS 1 / catkin package setup for model visualization in RViz.
It contains 10 links and 9 joints: 6 revolute, 2 prismatic and 1 fixed.
The original URDF and mesh files are included byte for byte, without changes.

## Contents

```text
Dr_arm_6_desk/
├── urdf/Dr_arm_6_desk.urdf
├── meshes/                  # All 10 meshes referenced by the URDF
├── launch/display.launch   # RViz and joint-state publishers
├── rviz/urdf.rviz           # Fixed frame: base_link
├── package.xml
├── CMakeLists.txt
└── README.md
```

## Environment

This is a ROS 1 / catkin package, not a ROS 2 package. Required runtime packages:
`roslaunch`, `robot_state_publisher`, `joint_state_publisher`,
`joint_state_publisher_gui`, and `rviz`.

The supplied source does not identify a tested ROS distribution. ROS/RViz runtime
testing has not been performed for this download. The steps below assume an
existing ROS 1 desktop installation and a shell with that ROS environment sourced.

## Setup and display

1. Extract the archive and copy the **entire** `Dr_arm_6_desk` directory into the
   `src` directory of your catkin workspace, for example `~/catkin_ws/src/`.
   Keep the package name and folder structure unchanged: the URDF resolves meshes
   through `package://Dr_arm_6_desk/meshes/...`.
2. From the workspace root, install the declared dependencies using your existing
   rosdep setup, build, and source the workspace:

   ```bash
   cd ~/catkin_ws
   rosdep install --from-paths src/Dr_arm_6_desk --ignore-src -r -y
   catkin_make
   source devel/setup.bash
   ```

3. Open the model and the joint sliders:

   ```bash
   roslaunch Dr_arm_6_desk display.launch
   ```

   For a static pose without the joint-slider window:

   ```bash
   roslaunch Dr_arm_6_desk display.launch gui:=false
   ```

The RViz configuration sets `base_link` as the fixed frame and enables RobotModel.
If a mesh cannot be found, check that the complete folder was copied and the
workspace was sourced. Do not copy only the `.urdf` file.

## Model scope and validation

- Intended for the course's URDF modeling and RViz visualization activities.
- XML structure, the connected link/joint tree, mesh references, binary STL
  structure and archive integrity were checked during packaging.
- ROS, catkin, RViz, motion planning and physical simulation have not been run
  in the packaging environment. No ROS distribution is claimed as tested.
- All movable joints in the supplied URDF have `effort="0"` and `velocity="0"`.
  These values have been preserved. Verify and configure physical/controller
  limits separately before using a planning or dynamics workflow.
- The URDF contains no transmission or Gazebo plugin configuration. MoveIt,
  Gazebo launch files and hardware-control drivers are outside this bundle.

## Packaging changes and source

Prepared from the model package supplied for this course. Original model authorship
is unspecified in the supplied manifest; Sen Li is the maintainer of this teaching
bundle. The URDF exporter attribution comment is retained.

The supplied `display.launch` referenced a missing `urdf.rviz` and had an unused,
required `model` argument. This bundle provides an RViz configuration and a launch
file with default arguments. Package metadata and installation paths were updated
to match this visualization-only bundle. Export logs, CAD-export CSV, Python
drivers/caches and unrelated simulation packages were omitted.

The original manifest declares `BSD`; this label is retained. No standalone
license text or model copyright holder was included in the source folder, and
this packaging does not assert new ownership of the supplied model assets.

Course page: https://www.sensedex.online/teaching/robotics-applications/
